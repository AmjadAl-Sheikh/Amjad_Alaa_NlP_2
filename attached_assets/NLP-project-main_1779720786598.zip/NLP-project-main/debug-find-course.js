const normalizeText = (txt) => txt
  .replace(/[أإآ]/g, 'ا')
  .replace(/ة/g, 'ه')
  .replace(/ى/g, 'ي')
  .replace(/[\u064B-\u065F]/g, '')
  .trim()
  .toLowerCase();
const findCourseMatch = (query, transcript) => {
  const normalizedQuery = normalizeText(query);
  return transcript.find((course) => {
    const normalizedName = normalizeText(course.name);
    const normalizedCode = normalizeText(course.code);
    return normalizedQuery.includes(normalizedName)
      || normalizedQuery.includes(normalizedCode)
      || normalizedQuery.split(' ').some((word) => normalizedName.includes(word));
  }) || null;
};
const transcript = [
  { code: 'CS201', name: 'هندسة برمجيات متقدمة', grade: 'A', creditHours: 3, status: 'ناجح' },
  { code: 'CS303', name: 'ذكاء اصطناعي', grade: 'B+', creditHours: 3, status: 'ناجح' },
  { code: 'CS315', name: 'أمن المعلومات', grade: 'A-', creditHours: 3, status: 'ناجح' },
  { code: 'CS220', name: 'هياكل بيانات', grade: 'B', creditHours: 3, status: 'ناجح' },
  { code: 'CS401', name: 'مشروع تخرج 1', grade: 'B+', creditHours: 4, status: 'مستمر' }
];
const q = 'ما علامتي في CS303';
console.log('normalized:', normalizeText(q));
console.log('match:', findCourseMatch(q, transcript));
