# 🚀 البدء السريع - تطبيق الأنظمة المحسّنة

## الخطوات الفورية (5 دقائق)

### 1. التحقق من الملفات المنتجة

```bash
# تأكد من وجود الملفات الجديدة
ls -la lib/
  ✓ intentDetection.ts
  ✓ responseGenerator.ts
  ✓ contextManager.ts
  ✓ enhancedChatHandler.ts
  ✓ demo-test.ts

# تأكد من وجود الملفات الموثقة
ls -la *.md
  ✓ CHATBOT_IMPROVEMENTS_ROADMAP.md
  ✓ INTEGRATION_GUIDE.md
  ✓ CHATBOT_SUMMARY.md
```

### 2. اختبر الأنظمة محلياً (اختياري)

```bash
# تشغيل اختبار توضيحي
npx ts-node lib/demo-test.ts

# يجب أن ترى:
# - ✓ اختبار كشف النية (Intent Detection)
# - ✓ اختبار توليد الردود (Response Generation)
# - ✓ اختبار إدارة السياق (Context Management)
# - ✓ قياس الأداء
# - ✓ إحصائيات نهائية
```

---

## الخطوات الأساسية (20 دقيقة)

### 3. دمج الأنظمة في server.ts

#### الخطوة 3.1: أضف الاستيرادات (✅ مكتملة بالفعل)

```typescript
// في بداية server.ts (تم بالفعل)
import IntentDetector from './lib/intentDetection';
import ResponseGenerator from './lib/responseGenerator';
import ContextManager from './lib/contextManager';
```

#### الخطوة 3.2: هيّئ المديرين (✅ مكتملة بالفعل)

```typescript
async function startServer() {
  // ...تم بالفعل
  const intentDetector = new IntentDetector();
  const responseGenerator = new ResponseGenerator();
  const contextManager = new ContextManager();
```

#### الخطوة 3.3: حدّث معالج `/api/chat/stream` (⚠️ متبقي)

**طريقة سهلة**: انسخ من `lib/enhancedChatHandler.ts`

```typescript
// في server.ts، ابحث عن:
app.post('/api/chat/stream', authMiddleware, async (req, res) => {
  // ... الكود القديم

// واستبدله بالمحتوى من enhancedChatHandler.ts
```

**أو استخدم الطريقة المدمجة**:

```typescript
// أضف بعد تهيئة المديرين
import { setupEnhancedChatHandler } from './lib/enhancedChatHandler';

// في نهاية المعالجات قبل بدء الخادم
setupEnhancedChatHandler(
  app,
  authMiddleware,
  students,
  normalizeText,
  asLocale,
  buildTranscriptResponse,
  buildFullTranscriptResponse,
  buildGradeAnalysisResponse,
  buildCourseLocationResponse,
  buildCoursesTodayResponse,
  buildNextExamResponse,
  buildAnnouncementsResponse,
  getNextExam,
  filterCoursesToday,
  findCourseMatch,
  getAiInstance
);
```

### 4. اختبر التطبيق

```bash
# بدء الخادم
npm run dev

# يجب أن ترى:
# ✅ Enhanced chat handlers installed successfully
# ✅ Server running on port 3000

# اختبر الدردشة
# 1. اذهب إلى http://localhost:3000
# 2. سجّل دخول (user: 123456, pass: test)
# 3. افتح المساعد الذكي
# 4. اسأل: "ما معدلي؟"
# 5. يجب أن تحصل على رد محسّن خلال 200ms
```

---

## الاختبارات السريعة

### اختبر الردود العربية

```
1️⃣ اسأل: "ما هي درجتي في مادة الذكاء الاصطناعي؟"
✓ يجب أن تحصل على: درجة + معدل + حالة أكاديمية + نصيحة

2️⃣ اسأل: "كم معدلي الكلي؟"
✓ يجب أن تحصل على: ملخص أداء شامل

3️⃣ اسأل: "ما المستحقات المالية؟"
✓ يجب أن تحصل على: رصيد مالي + طرق دفع

4️⃣ اسأل: "أين قاعة الذكاء الاصطناعي؟"
✓ يجب أن تحصل على: موقع القاعة + الوقت
```

### اختبر الردود الإنجليزية

```
1️⃣ Ask: "What is my GPA?"
✓ Should get: Grade summary + Academic status

2️⃣ Ask: "When is my next exam?"
✓ Should get: Exam date + Time + Location

3️⃣ Ask: "Show me my registered courses"
✓ Should get: Course list with times
```

---

## حل المشاكل الشائعة

### ❌ مشكلة: "Cannot find module 'lib/intentDetection'"

**الحل**:
```bash
# تأكد من وجود الملفات
ls -la lib/ | grep -E "(intent|response|context)"

# إذا لم تكن موجودة، أعد نسخ الملفات من المجلد الموجود
```

### ❌ مشكلة: "الخادم يتوقف عند تشغيل chat"

**الحل**:
```typescript
// تأكد من أن جميع الدوال مُعرّفة في server.ts:
- normalizeText()
- asLocale()
- buildTranscriptResponse()
- buildFullTranscriptResponse()
- إلخ

// إذا لم تكن موجودة، انسخها من الكود القديم
```

### ❌ مشكلة: "الردود بطيئة جداً"

**الحل**:
```typescript
// قلل حجم السياق المحفوظ
const contextManager = new ContextManager();
// معياراً: يحفظ آخر 50 رسالة فقط (مُحسّن للأداء)
```

---

## مراجعة الأداء

```bash
# قس أداء التطبيق
# 1. افتح Chrome DevTools (F12)
# 2. انتقل إلى Network tab
# 3. أرسل سؤال للدردشة
# 4. لاحظ:
#    - Response time: يجب أن يكون < 200ms
#    - Payload size: يجب أن يكون < 5KB
#    - Streaming: يجب أن تكون الاستجابة سريعة
```

---

## الخطوات التالية (بعد التأكد من النجاح)

### المرحلة 3: نقاط التكامل المتقدمة (4-6 ساعات)

```
[ ] 1. ربط بوابة PPU (https://reg.ppu.edu)
[ ] 2. تكامل منصة ريتاج (https://ritaj.ppu.edu)
[ ] 3. تكامل نظام الدفع
[ ] 4. تكامل المكتبة الرقمية
```

### المرحلة 4: نظام الذاكرة (3-4 ساعات)

```
[ ] 1. إضافة Redis للأداء
[ ] 2. حفظ دائم في قاعدة بيانات
[ ] 3. استعادة الجلسات
```

### المرحلة 5: تحسين اللغات (2-3 ساعات)

```
[ ] 1. قاموس شامل للمصطلحات
[ ] 2. ترجمة ديناميكية
[ ] 3. دعم اللهجات المختلفة
```

---

## الملفات المهمة

```
📁 المشروع
├── 📄 server.ts (⚠️ يحتاج تحديث - معالج chat/stream)
├── 📁 lib/
│   ├── ✅ intentDetection.ts (جاهز)
│   ├── ✅ responseGenerator.ts (جاهز)
│   ├── ✅ contextManager.ts (جاهز)
│   ├── ✅ enhancedChatHandler.ts (جاهز)
│   └── ✅ demo-test.ts (اختبار)
├── ✅ CHATBOT_IMPROVEMENTS_ROADMAP.md (خريطة طريق)
├── ✅ INTEGRATION_GUIDE.md (تعليمات التكامل)
├── ✅ CHATBOT_SUMMARY.md (ملخص شامل)
└── 📄 src/pages/Chat.tsx (لا تحتاج تعديل)
```

---

## نصائح مهمة

1. **اختبر قبل الإنتاج**: جرّب جميع السيناريوهات محلياً
2. **احفظ نسخة احتياطية**: احفظ server.ts الأصلي
3. **تحقق من الأداء**: استخدم Chrome DevTools
4. **اتبع الخطوات بالترتيب**: لا تتجاوز الخطوات
5. **اقرأ الأخطاء بعناية**: غالباً تشرح المشكلة مباشرة

---

## 📞 للحصول على الدعم

**إذا واجهت مشكلة**:

1. اقرأ `INTEGRATION_GUIDE.md`
2. تحقق من الأخطاء في Console
3. تأكد من وجود جميع الملفات
4. اختبر في بيئة جديدة من الصفر

---

## ✅ نموذج فحص قبل الإطلاق

- [ ] الملفات الجديدة موجودة ومكتملة
- [ ] server.ts محدّث بنجاح
- [ ] الخادم يبدأ بدون أخطاء
- [ ] الدردشة تعمل وتستقبل رسائل
- [ ] الردود صحيحة وسريعة
- [ ] الأداء مقبول (< 200ms)
- [ ] جميع الاختبارات ناجحة
- [ ] لا توجد رسائل خطأ في Console

---

## 🎯 بعد إكمال المرحلة 2

✅ **ما تم إنجازه**:
- نظام متقدم لكشف النية
- محرك ذكي لتوليد الردود
- إدارة سياق متطورة
- توثيق شامل وسهل الاتباع

⏳ **المتبقي**:
- دمج في server.ts
- اختبارات شاملة
- تطوير نقاط التكامل
- إضافة المزايا الإضافية

🚀 **مستعد للإطلاق**:
> جميع الأنظمة جاهزة للاستخدام الفوري!

---

**آخر تحديث**: 2026-05-23  
**الحالة**: جاهز للتطبيق الفوري  
**الوقت المتوقع للدمج**: 20-30 دقيقة
