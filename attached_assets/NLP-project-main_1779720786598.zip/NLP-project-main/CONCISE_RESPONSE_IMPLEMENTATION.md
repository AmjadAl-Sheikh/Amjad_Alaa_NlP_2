/**
 * IMPLEMENTATION GUIDE: Concise Response Mode
 * How to use the new ConciseResponseGenerator in your chat handler
 */

// ============================================
// STEP 1: ADD THIS IMPORT
// ============================================

import { conciseResponseGenerator } from './lib/conciseResponseGenerator';

// ============================================
// STEP 2: UPDATE RESPONSE GENERATION
// ============================================

// In your /api/chat/stream handler, replace the response generation section with:

// When sending a response about grades:
// ❌ OLD (too verbose):
// "مرحباً أحمد، علامتك في الرياضيات هي 92%، وهذا يعتبر درجة ممتازة..."

// ✅ NEW (concise):
// "الرياضيات: 92%"

// ============================================
// STEP 3: FULL EXAMPLE IMPLEMENTATION
// ============================================

// In /api/chat/stream handler:
app.post('/api/chat/stream', authMiddleware, async (req: any, res: any) => {
  const { messages, studentContext } = req.body;
  const lastUserMsg = messages[messages.length - 1].content;
  const currentUser = (req as any).user;

  // Determine if this is a specific question
  const isSpecificQuestion = conciseResponseGenerator.detectQuestionSpecificity(lastUserMsg);
  
  // Detect if asking for single course
  const isSingleCourse = conciseResponseGenerator.isAskingForSingleCourse(lastUserMsg);
  
  // Extract course name if applicable
  const courseName = isSingleCourse ? conciseResponseGenerator.extractCourseName(lastUserMsg) : null;

  const locale = asLocale(lastUserMsg);
  const normMsg = normalizeText(lastUserMsg);

  let responseText = '';

  // ==========================================
  // EXAMPLE 1: GRADES QUERY
  // ==========================================
  
  if (isGradeQuery) {
    if (isSingleCourse && courseName) {
      // User asking: "علامة الرياضيات؟"
      // Response: "الرياضيات: 92%"
      const course = currentUser.transcript.find((c: any) => 
        normalizeText(c.code) === normalizeText(courseName) ||
        normalizeText(c.name) === normalizeText(courseName)
      );

      if (course) {
        responseText = conciseResponseGenerator.formatGradeResponse(
          course.name,
          course.grade,
          locale
        );
      }
    } else if (isSpecificQuestion && lastUserMsg.includes('كشف') || lastUserMsg.includes('كامل') || lastUserMsg.includes('all')) {
      // User asking: "اعرض كشفي"
      // Response: Complete list of grades
      responseText = conciseResponseGenerator.formatGradesResponse(
        currentUser.transcript,
        locale
      );
    } else if (lastUserMsg.includes('معدل') || lastUserMsg.includes('gpa')) {
      // User asking: "كام معدلي؟"
      // Response: "معدلك: 85%"
      responseText = locale === 'ar'
        ? `معدلك التراكمي: **${currentUser.gpa}%**`
        : `Your GPA: **${currentUser.gpa}%**`;
    } else {
      // Generic grade question
      responseText = conciseResponseGenerator.formatGradesResponse(
        currentUser.transcript.slice(0, 5), // Show last 5 courses
        locale
      );
    }
  }

  // ==========================================
  // EXAMPLE 2: SCHEDULE QUERY
  // ==========================================
  
  else if (isScheduleQuery) {
    if (isSpecificQuestion) {
      const todayClasses = filterCoursesToday(currentUser.courses);
      responseText = conciseResponseGenerator.formatScheduleResponse(
        todayClasses,
        locale
      );
    } else {
      // General schedule question
      const todayClasses = filterCoursesToday(currentUser.courses);
      responseText = conciseResponseGenerator.formatScheduleResponse(
        todayClasses,
        locale
      );
    }
  }

  // ==========================================
  // EXAMPLE 3: LOCATION QUERY
  // ==========================================
  
  else if (isLocationQuery && isSingleCourse && courseName) {
    const course = currentUser.courses.find((c: any) =>
      normalizeText(c.code) === normalizeText(courseName) ||
      normalizeText(c.name) === normalizeText(courseName)
    );

    if (course) {
      // User asking: "أين محاضرة البرمجة؟"
      // Response: "قاعة 205 - مبنى العلوم"
      responseText = conciseResponseGenerator.formatLocationResponse(
        course.room,
        course.building || 'مبنى الهندسة',
        course.floor || '2',
        locale
      );
    }
  }

  // ==========================================
  // EXAMPLE 4: EXAM QUERY
  // ==========================================
  
  else if (isExamQuery) {
    if (isSingleCourse && courseName) {
      const exam = getNextExam(currentUser.exams, courseName);
      if (exam) {
        // User asking: "متى امتحان الرياضيات؟"
        // Response: "📝 الرياضيات\n📅 2026-05-30\n🕐 2:00 PM\n📍 قاعة 301"
        responseText = conciseResponseGenerator.formatExamResponse(
          exam.courseName,
          exam.date,
          exam.time,
          exam.location,
          locale
        );
      }
    } else {
      // General next exam
      const nextExam = getNextExam(currentUser.exams);
      if (nextExam) {
        responseText = conciseResponseGenerator.formatExamResponse(
          nextExam.courseName,
          nextExam.date,
          nextExam.time,
          nextExam.location,
          locale
        );
      }
    }
  }

  // ==========================================
  // EXAMPLE 5: FINANCIAL QUERY
  // ==========================================
  
  else if (isFinancialQuery) {
    if (lastUserMsg.includes('رسوم') || lastUserMsg.includes('fee') || lastUserMsg.includes('cost')) {
      // User asking: "كام الرسوم؟"
      // Response: "سعر الساعة: 50 دينار"
      responseText = conciseResponseGenerator.formatFinancialResponse(
        'fees',
        50, // Fee per hour
        'دينار أردني',
        locale
      );
    } else {
      // Asking about balance
      // User asking: "كام رصيدي؟"
      // Response: "رصيدك: 450 دينار"
      responseText = conciseResponseGenerator.formatFinancialResponse(
        'balance',
        currentUser.balance,
        'دينار أردني',
        locale
      );
    }
  }

  // ==========================================
  // STEP 4: SEND RESPONSE
  // ============================================

  // Streaming the response
  res.write(`data: ${JSON.stringify({ 
    text: responseText,
    isSpecific: isSpecificQuestion,
    isSingleCourse: isSingleCourse,
    mode: isSpecificQuestion ? 'concise' : 'detailed'
  })}\n\n`);

  res.write(`data: ${JSON.stringify({ type: 'stream_end' })}\n\n`);
  res.end();
});

// ============================================
// EXAMPLES OF BEHAVIOR
// ============================================

/*
EXAMPLE 1: SINGLE COURSE GRADE
─────────────────────────────────────────────
User:     "علامة الرياضيات؟"
Before:   "مرحباً أحمد، علامتك في الرياضيات هي 92%، 
           وهذا يعتبر درجة جيدة جداً. يمكنك..."
After:    "الرياضيات: 92%"
─────────────────────────────────────────────

EXAMPLE 2: ALL GRADES
─────────────────────────────────────────────
User:     "اعرض جميع درجاتي"
Before:   "مرحباً أحمد، إليك جميع درجاتك مع ملاحظات..."
After:    "📊 درجاتك:
           • الرياضيات: 92%
           • البرمجة: 88%
           • قاعدة البيانات: 85%"
─────────────────────────────────────────────

EXAMPLE 3: LOCATION
─────────────────────────────────────────────
User:     "أين قاعة البرمجة؟"
Before:   "يبدو أنك تسأل عن موقع البرمجة، 
           وهي توجد في..."
After:    "قاعة 202 - مبنى الهندسة (الطابق 2)"
─────────────────────────────────────────────

EXAMPLE 4: EXAM DATE
─────────────────────────────────────────────
User:     "متى امتحان الرياضيات؟"
Before:   "استعداداً لامتحان الرياضيات، عليك معرفة أن..."
After:    "📝 الرياضيات
           📅 2026-05-30
           🕐 2:00 PM
           📍 قاعة 301"
─────────────────────────────────────────────

EXAMPLE 5: BALANCE
─────────────────────────────────────────────
User:     "كام الرسوم؟"
Before:   "رسوم الجامعة حسب عدد الساعات، 
           والحد الأدنى..."
After:    "سعر الساعة: 50 دينار أردني"
─────────────────────────────────────────────

EXAMPLE 6: TODAY'S SCHEDULE
─────────────────────────────────────────────
User:     "شنو جدولي اليوم؟"
Before:   "حسب جدولك، لديك المحاضرات التالية اليوم..."
After:    "محاضراتك اليوم:
           • البرمجة - 8:00 AM (قاعة 102)
           • الرياضيات - 10:30 AM (قاعة 205)
           • الشبكات - 2:00 PM (قاعة 308)"
─────────────────────────────────────────────
*/

// ============================================
// CONFIGURATION
// ============================================

// To disable concise mode and always use detailed responses:
// Change the condition to:
// const isSpecificQuestion = false;

// To enable more verbose responses:
// const isSpecificQuestion = conciseResponseGenerator.detectQuestionSpecificity(lastUserMsg) && someOtherCondition;

// To customize response length, modify the templates in conciseResponseGenerator.ts
