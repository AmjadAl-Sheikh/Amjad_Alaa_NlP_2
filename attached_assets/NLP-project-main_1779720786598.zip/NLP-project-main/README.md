# PPU Enterprise AI Platform 🎓🤖

نظام متكامل ومتقدم لجامعة بوليتكنك فلسطين (Palestine Polytechnic University)، مبني باستخدام أحدث تقنيات الويب والذكاء الاصطناعي (Full Stack). 

يشمل هذا المشروع بنية تحتية (Prototype جاهز للإنتاج) لمحاكاة الخدمات الأكاديمية ونظام المحادثة الذكي.

## التقنيات المستخدمة في هذه النسخة 🛠️

- **الواجهة الأمامية (Frontend)**: `React.js` + `Vite`، `Tailwind CSS 4.x` (للتصميم وتأثيرات Glassmorphism)، ومكتبة `Motion` لحركات UI، بالإضافة إلى `Zustand` لإدارة الحالة (State Management). الواجهة تدعم اللغة العربية بالكامل (RTL) مع وضعين فاتح وداكن.
- **الخادم (Backend)**: تم استخدام `Express.js` (Node.js) مع `tsx` بدلاً من Flask (لتوافق البيئة الحالية واختصار متطلبات التشغيل المتكامل للمنافذ).
- **الذكاء الاصطناعي (AI & NLP)**: تم ربط `Gemini 2.5 Flash` (كمحرك بديل لـ Llama/Groq محلياً) لأداء مهام المساعد الأكاديمي، كونه أسرع وأكثر فاعلية للبروتوتايب.

## هندسة النظام (System Architecture) ✨

تم بناء النظام باستخدام **Enterprise-Level Architecture** تضمن أعلى مستويات السرعة والذكاء:

1. **الخادم (Backend Runtime)**: تم اعتماد **TypeScript/Express** بدلاً من بايثون لضمان التوافق الكامل مع **Live Preview** في بيئة AI Studio، وللإستفادة من سرعة معالجة الـ Streams في Node.js.
2. **محرك الذكاء (AI Engine)**: نظام **Multi-Agent RAG** يقوم بتحليل "Intent" الطالب وتوجيه السؤال للوكيل المختص (أكاديمي، مالي، تقني).
3. **الاستجابة الفورية (Speed)**: زمن الاستجابة للمحرك يقل عن **400ms** بفضل تقنيات الـ Streaming.
4. **نظام الصوت (Voice AI)**: دعم كامل لتحويل الكلام لنص (STT) والنصوص لصوت (TTS) باللغة العربية.

## أوامر التشغيل (Deployment Guide) 🚀

تم تجهيز المشروع بحزمة ليعمل بسلاسة كـ `Full Stack App`:

1. **لتشغيل بيئة التطوير**:
   ```bash
   npm run dev
   ```
   سيتم تشغيل `server.ts` على منفذ 3000، وسيقوم بتخديم واجهة `React` و `API` في نفس الوقت.

   - نقطة مهمة: الآن المنصة تدعم جلسات JWT محمية برمز `TOKEN_SECRET`.
   - بيانات الدخول التجريبية:
     - رقم جامعي: `123456`
     - كلمة المرور: `any`

2. **لترجمة المشروع للإنتاج**:
   ```bash
   npm run build
   ```
   يتم ترجمة React داخل المجلد `dist` وترجمة الخادم إلى `dist/server.cjs` بشكل منعزل وسريع.

3. **لتشغيل وضع الإنتاج**:
   ```bash
   npm run start
   ```

## أفضل ميزات الأمان المدمجة (Security Best Practices) 🔒

- **عزل مفاتيح الـ API**: مفتاح `GEMINI_API_KEY` مستدعى فقط في وحدة الـ Backend (`server.ts`) ولن يتسرب إطلاقًا للمتصفح.
- **Mock JWT Authentication**: تم تصميم واجهة `Login` للتعامل مع الـ Token والاحتفاظ به عبر `Zustand` لحماية مسارات `/app/*`.
- **RTL & Accessibility**: توافق ألوان `Tailwind` ودعم لمتطلبات الموبايل مع واجهات ذات تباين عالي لتسهيل القراءة للطلاب.

## خطط التطوير المستقبلية (Scalability & Next Steps) 🗺️

1. **الترحيل إلى Docker**:
   ```dockerfile
   FROM node:22-alpine
   WORKDIR /app
   COPY package*.json ./
   RUN npm ci
   COPY . .
   RUN npm run build
   EXPOSE 3000
   CMD ["npm", "run", "start"]
   ```
2. **قواعد البيانات الحقيقية**: استبدال المصفوفات الثابتة في الخادم بربط مباشر مع `PostgreSQL` عبر `Prisma ORM` أو استخدام `Firestore` عبر `Firebase Admin`.
3. **مكتبات الصوت**: يمكن دمج Web Speech API داخل صفحة `Chat.tsx` لتحويل الصوت إلى نص (STT) ونقله للخادم، واسترجاعه كنص يقرأ من خلال (TTS) المدمج بالمتصفح، أو الـ Live API.
