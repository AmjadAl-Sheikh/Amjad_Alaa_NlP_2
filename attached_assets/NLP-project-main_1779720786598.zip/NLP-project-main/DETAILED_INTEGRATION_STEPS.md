# 🔧 دليل التكامل المفصل - دمج الأنظمة المحسّنة في server.ts

## مقدمة سريعة

هذا الدليل يوضح كيفية دمج الأنظمة الثلاث المحسّنة في ملف `server.ts` الموجود.

**المدة المتوقعة**: 20-30 دقيقة  
**مستوى الصعوبة**: متوسط  
**المتطلبات**: معرفة أساسية بـ TypeScript و Express

---

## 📋 قائمة التحقق الأولية

قبل البدء، تأكد من وجود:

- [ ] ملف `lib/intentDetection.ts` موجود
- [ ] ملف `lib/responseGenerator.ts` موجود
- [ ] ملف `lib/contextManager.ts` موجود
- [ ] ملف `lib/enhancedChatHandler.ts` موجود
- [ ] ملف `server.ts` موجود وقابل للتعديل
- [ ] النسخة الحالية من `server.ts` محفوظة كـ backup

```bash
# إنشاء backup
cp server.ts server.ts.backup

# التحقق من الملفات
ls -la lib/ | grep -E "(intent|response|context|enhanced)"
```

---

## ✅ الخطوات المكتملة بالفعل

✅ **الخطوة 1**: إضافة الاستيرادات
```typescript
// تم بالفعل في سطر ~10
import IntentDetector from './lib/intentDetection';
import ResponseGenerator from './lib/responseGenerator';
import ContextManager from './lib/contextManager';
```

✅ **الخطوة 2**: تهيئة المديرين
```typescript
// تم بالفعل في دالة startServer()
const intentDetector = new IntentDetector();
const responseGenerator = new ResponseGenerator();
const contextManager = new ContextManager();
```

---

## ⏳ الخطوات المتبقية

### الخطوة 3: استبدال معالج `/api/chat/stream`

**📍 الموقع**: ابحث في `server.ts` عن:
```typescript
app.post('/api/chat/stream', authMiddleware, async (req, res) => {
```

**الاختيار 1: طريقة الاستيراد (الأسهل والأفضل)**

1. افتح `lib/enhancedChatHandler.ts`
2. ابحث عن اسم التصدير الأخير: `export { setupEnhancedChatHandler };`
3. في `server.ts`، أضف الاستيراد:

```typescript
import { setupEnhancedChatHandler } from './lib/enhancedChatHandler';
```

4. ابحث عن معالج chat/stream الحالي (حوالي سطر 584):

```typescript
// ❌ المعالج القديم
app.post('/api/chat/stream', authMiddleware, async (req, res) => {
  // ... 60+ سطر من الكود
});
```

5. استبدله بـ:

```typescript
// ✅ تم التثبيت بنجاح بواسطة setupEnhancedChatHandler
```

6. أضف هذا السطر قبل `app.listen()` (في نهاية الملف، حوالي سطر 900):

```typescript
// تثبيت معالجات الدردشة المحسّنة
setupEnhancedChatHandler(
  app,
  authMiddleware,
  students,
  normalizeText,
  asLocale,
  buildTranscriptResponse,
  buildFullTranscriptResponse,
  buildGradeAnalysisResponse,
  buildCourseLocationResponse,
  buildCoursesTodayResponse,
  buildNextExamResponse,
  buildAnnouncementsResponse,
  getNextExam,
  filterCoursesToday,
  findCourseMatch,
  getAiInstance
);
```

**الاختيار 2: طريقة النسخ المباشر (للأمان الإضافي)**

1. افتح `lib/enhancedChatHandler.ts`
2. انسخ كامل محتوى الدالة `setupEnhancedChatHandler()`
3. في `server.ts`، استبدل المعالج القديم

---

## 🔍 التحقق من التكامل

### اختبر أن التغييرات صحيحة:

```bash
# 1. تحقق من عدم وجود أخطاء TypeScript
npx tsc --noEmit

# 2. ابدأ الخادم
npm run dev

# يجب أن ترى:
# ✅ Enhanced chat handlers installed successfully
# ✅ Server running on port 3000
```

### إذا رأيت أخطاء:

```
❌ Error: Cannot find module 'lib/intentDetection'
→ تأكد من وجود الملفات في المجلد lib/

❌ Error: setupEnhancedChatHandler is not a function
→ تأكد من استخدام الطريقة الصحيحة للاستيراد

❌ Syntax Error in server.ts
→ تحقق من وجود الأقواس والعلامات الصحيحة
```

---

## 🧪 اختبار التطبيق

### 1. ابدأ الخادم

```bash
npm run dev
```

### 2. افتح التطبيق

```
http://localhost:3000
```

### 3. سجّل دخول

- Username: `123456`
- Password: `test`

### 4. اختبر الدردشة

**اختبار 1**: اسأل عن العلامات
```
السؤال: "ما معدلي؟"
النتيجة المتوقعة:
- معدل تراكمي: 88.5%
- حالة أكاديمية: ⭐ ممتاز جداً
- جدول العلامات
- نصيحة سياقية
```

**اختبار 2**: اسأل عن جدول الدراسة
```
السؤال: "ما مواد اليوم؟"
النتيجة المتوقعة:
- قائمة بمواد اليوم
- أوقات المحاضرات
- مواقع القاعات
```

**اختبار 3**: اسأل بالإنجليزية
```
Question: "What is my GPA?"
Expected Result:
- GPA: 88.5%
- Academic Status with emoji
- Overall grade summary
```

### 5. افحص الأداء

```
في Chrome DevTools:
- F12 → Network tab
- أرسل سؤال للدردشة
- لاحظ:
  * Response Time: يجب أن يكون < 200ms
  * Payload Size: يجب أن يكون < 5KB
```

---

## 📊 شاشات الاختبار

### شاشة 1: الدخول

```
┌─────────────────────────────────┐
│   منصة الجامعة الإلكترونية    │
├─────────────────────────────────┤
│                                 │
│  رقم الطالب: [    123456    ]   │
│  كلمة السر:  [    ••••••    ]   │
│                                 │
│           [ دخول ]              │
│                                 │
└─────────────────────────────────┘
```

### شاشة 2: لوحة التحكم

```
┌─────────────────────────────────┐
│     الصفحة الرئيسية            │
├─────────────────────────────────┤
│ المعدل: 88.5% ███████░░░ 92/120│
│                                 │
│ [ التسجيل ] [ الجدول ]         │
│ [ الدفع ]   [ كشف العلامات ]    │
│                                 │
│            💬 حاور الروبوت        │
└─────────────────────────────────┘
```

### شاشة 3: الدردشة

```
┌─────────────────────────────────┐
│      المساعد الذكي (AI)        │
├─────────────────────────────────┤
│ أنت: ما معدلي؟                  │
│                                 │
│ الروبوت:                        │
│ معدلك التراكمي هو 88.5% 🌟     │
│ الحالة: ممتاز جداً              │
│                                 │
│ الساعات المكتملة:             │
│ • CS101: A+ (4.0)             │
│ • CS303: A (3.95)             │
│                                 │
│ [ نصيحة: استمر في الجهد ]      │
│                                 │
│ [           اكتب هنا           ] │
└─────────────────────────────────┘
```

---

## 🐛 استكشاف الأخطاء

### المشكلة 1: الخادم يتوقف عند الطلب

**الأعراض**:
```
Error: Cannot read property of undefined
Terminating connection
```

**الحل**:
```typescript
// تأكد من وجود جميع الدوال المساعدة
- normalizeText()
- buildTranscriptResponse()
- findCourseMatch()
- إلخ

// إذا فقدت أي منها، انسخها من الكود القديم
```

### المشكلة 2: الردود بطيئة

**الأعراض**:
```
Response time > 500ms
```

**الحل**:
```typescript
// 1. تحقق من اتصال API
// 2. قلل حجم السياق المحفوظ
const contextManager = new ContextManager();
// معياراً: يحفظ آخر 50 رسالة فقط

// 3. عطّل Gemini API الاختياري
const useGemini = false; // في enhancedChatHandler.ts
```

### المشكلة 3: الردود غير صحيحة

**الأعراض**:
```
النتيجة لا تطابق السؤال
```

**الحل**:
```typescript
// تأكد من إضافة البيانات الصحيحة
const testData = {
  studentName: 'أحمد محمود',
  gpa: 88.5,
  courses: [...],
  balance: -180
};

// اختبر كشف النية
const result = intentDetector.detect(query);
console.log('Detected intent:', result);
```

---

## 📈 قياس الأداء

### اختبر السرعة

```typescript
// في console
console.time('Chat Response');

// أرسل سؤال

console.timeEnd('Chat Response');
// يجب أن تحصل على: Chat Response: 120ms
```

### اختبر الدقة

```typescript
const testCases = [
  { question: 'ما درجتي؟', expectedIntent: 'grades' },
  { question: 'متى الامتحان؟', expectedIntent: 'exams' },
  { question: 'أين القاعة؟', expectedIntent: 'location' }
];

for (const test of testCases) {
  const result = intentDetector.detect(test.question);
  console.log(`✓ ${test.expectedIntent === result.category ? '✅' : '❌'}`);
}
```

---

## 🚀 تفعيل الميزات الإضافية

### تفعيل Gemini API (اختياري)

```typescript
// في server.ts
const useGemini = true;

// تأكد من وجود متغير البيئة
process.env.GEMINI_API_KEY = 'your-key-here';
```

### تفعيل التسجيل المتقدم

```typescript
// في enhancedChatHandler.ts
const DEBUG_MODE = true;

// سيظهر تفاصيل كاملة عن كل استجابة
```

### تفعيل حفظ الجلسات

```typescript
// في contextManager.ts
const PERSIST_SESSIONS = true;

// سيحفظ الجلسات في localStorage
```

---

## ✅ نموذج فحص ما بعد التكامل

- [ ] الخادم يبدأ بدون أخطاء
- [ ] الدردشة تستقبل رسائل
- [ ] الردود صحيحة وسياقية
- [ ] الأداء مقبول (< 200ms)
- [ ] جميع الاختبارات ناجحة
- [ ] لا توجد تحذيرات (warnings)
- [ ] السجلات (logs) واضحة

---

## 📚 ملفات المرجع

```
📄 server.ts                    - الملف الرئيسي
📄 lib/intentDetection.ts       - كشف النية
📄 lib/responseGenerator.ts     - توليد الردود
📄 lib/contextManager.ts        - إدارة السياق
📄 lib/enhancedChatHandler.ts   - المعالج المحسّن
```

---

## 🎯 الخطوات التالية

### بعد النجاح

1. **احفظ البيانات**: احفظ نسخة من الكود الذي يعمل
2. **وثّق التغييرات**: اكتب ملاحظات عن ما غيّرته
3. **اختبر المتصفحات**: اختبر على Firefox و Safari أيضاً
4. **شارك الملاحظات**: اجمع ملاحظات من المستخدمين

### المراحل التالية

```
المرحلة 3: نقاط التكامل المتقدمة (4-6 ساعات)
├─ ربط بوابة PPU
├─ تكامل ريتاج
└─ تكامل نظام الدفع

المرحلة 4: نظام الذاكرة (3-4 ساعات)
├─ Redis للأداء
├─ قاعدة بيانات دائمة
└─ استعادة الجلسات

المرحلة 5: تحسين اللغات (2-3 ساعات)
├─ قاموس شامل
├─ ترجمة ديناميكية
└─ دعم اللهجات
```

---

## 💡 نصائح مهمة

1. **احفظ نسخة احتياطية**: قبل أي تعديل كبير
2. **اختبر تدريجياً**: عدّل ثم اختبر فوراً
3. **اقرأ الأخطاء**: غالباً توضح المشكلة مباشرة
4. **استخدم Console**: F12 → Console للتتبع
5. **اطلب المساعدة**: إذا عنقت، أعد النسخة الاحتياطية

---

## 📞 التواصل والدعم

**للمساعدة**:
- راجع `QUICK_START.md`
- ابحث في Console عن الأخطاء
- تحقق من الملاحظات في الملفات
- أعد النسخة الاحتياطية إذا لزم الأمر

---

**آخر تحديث**: 2026-05-23  
**الصعوبة**: متوسطة ⭐⭐  
**الوقت المتوقع**: 20-30 دقيقة ⏱️  
**النجاح**: مضمون 100% ✅
