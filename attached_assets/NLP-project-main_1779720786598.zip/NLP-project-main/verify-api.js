const fetch = globalThis.fetch;
(async () => {
  const login = await fetch('http://localhost:3000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ studentId: '123456', password: 'any' }),
  }).then((r) => r.json());
  const token = login.token;
  console.log('token', token);
  for (const path of ['/api/student/courses', '/api/student/exams', '/api/student/announcements', '/api/student/schedule']) {
    const res = await fetch(`http://localhost:3000${path}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    console.log(path, res.status);
    console.log(await res.text());
  }
})();
