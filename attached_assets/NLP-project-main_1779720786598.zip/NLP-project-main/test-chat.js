const fetch = globalThis.fetch;
(async () => {
  const login = await fetch('http://localhost:3000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ studentId: '123456', password: 'any' }),
  }).then((r) => r.json());
  console.log('token', login.token);
  const res = await fetch('http://localhost:3000/api/chat/stream', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${login.token}`,
    },
    body: JSON.stringify({
      messages: [{ role: 'user', content: '?? ?????? ?? CS303' }],
      studentContext: { name: '???? ?????', major: '????? ?????', gpa: 88.5, hoursDone: 92 },
    }),
  });
  const reader = res.body.getReader();
  let text = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    text += new TextDecoder().decode(value);
  }
  console.log(text);
})();
