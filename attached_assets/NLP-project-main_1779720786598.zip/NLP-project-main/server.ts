import express, { type Request, type Response, type NextFunction } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { createHmac } from 'crypto';
import IntentDetector from './lib/intentDetection';
import ResponseGenerator from './lib/responseGenerator';
import ContextManager from './lib/contextManager';

const PORT = 3000;
const TOKEN_SECRET = process.env.TOKEN_SECRET || 'ppuaiplatform-dev-secret';
const TOKEN_TTL = 1000 * 60 * 60; // 1 hour

type CourseRecord = {
  code: string;
  name: string;
  grade: string;
  creditHours: number;
  status: 'ناجح' | 'راسب' | 'مستمر';
};

type CourseSchedule = {
  code: string;
  name: string;
  days: string[];
  time: string;
  room: string;
  type: 'وجاهي' | 'مدمج' | 'الكتروني';
};

type ExamRecord = {
  courseCode: string;
  courseName: string;
  date: string;
  time: string;
  location: string;
  examType: 'نهائي' | 'نصف فصل' | 'تجريبي';
};

type Announcement = {
  id: string;
  title: string;
  category: string;
  date: string;
  body: string;
  link?: string;
};

type Notification = {
  id: string;
  title: string;
  expiresAt: string;
  details: string;
};

type Student = {
  id: string;
  name: string;
  major: string;
  gpa: number;
  hoursDone: number;
  hoursTotal: number;
  balance: number;
  transcript: CourseRecord[];
  courses: CourseSchedule[];
  exams: ExamRecord[];
  announcements: Announcement[];
  notifications: Notification[];
};

const createSessionToken = (userId: string) => {
  const payload = JSON.stringify({ sub: userId, exp: Date.now() + TOKEN_TTL });
  const encoded = Buffer.from(payload).toString('base64url');
  const signature = createHmac('sha256', TOKEN_SECRET).update(encoded).digest('base64url');
  return `${encoded}.${signature}`;
};

const verifySessionToken = (token: string) => {
  const [encoded, signature] = token.split('.');
  if (!encoded || !signature) return null;
  const expected = createHmac('sha256', TOKEN_SECRET).update(encoded).digest('base64url');
  if (signature !== expected) return null;

  try {
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf-8')) as { sub: string; exp: number };
    if (payload.exp < Date.now()) return null;
    return payload.sub;
  } catch {
    return null;
  }
};

async function startServer() {
  const app = express();
  app.use(express.json());

  // Initialize advanced AI systems
  const intentDetector = new IntentDetector();
  const responseGenerator = new ResponseGenerator();
  const contextManager = new ContextManager();

  // Graceful initialization of Gemini API
  const getAiInstance = () => {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      return null;
    }
    return new GoogleGenAI({ apiKey: key });
  };

  const normalizeText = (txt: string) => txt
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[\u064B-\u065F]/g, '')
    .trim()
    .toLowerCase();

  const findCourseMatch = (query: string, transcript: CourseRecord[]) => {
    const normalizedQuery = normalizeText(query);
    return transcript.find((course) => {
      const normalizedName = normalizeText(course.name);
      const normalizedCode = normalizeText(course.code);
      return normalizedQuery.includes(normalizedName) || normalizedQuery.includes(normalizedCode) || normalizedQuery.split(' ').some(word => normalizedName.includes(word));
    }) || null;
  };

  const buildTranscriptResponse = (studentName: string, course: CourseRecord, studentId: string, gpa: number, locale: 'ar' | 'en' = 'ar') => {
    if (locale === 'en') {
      return `### 📚 Course Result: ${course.name} (${course.code})

* **Student:** ${studentName}
* **University ID:** ${studentId}
* **Current GPA:** ${gpa}%
* **Credit Hours:** ${course.creditHours}
* **Final Grade:** ${course.grade}
* **Status:** ${course.status}

If you want, I can also show your full transcript or calculate how this course impacts your GPA.`;
    }

    return `### 📚 نتائج مادة ${course.name} (${course.code})

* **الطالب:** ${studentName}
* **الرقم الجامعي:** ${studentId}
* **المعدل التراكمي الحالي:** ${gpa}%
* **الساعات المعتمدة للمادة:** ${course.creditHours} ساعة
* **التقدير النهائي:** ${course.grade}
* **الحالة:** ${course.status}

إذا رغبت، يمكنني أيضاً عرض كشف العلامات الكامل أو حساب تأثير هذه المادة على المعدل التراكمي.`;
  };

  const buildFullTranscriptResponse = (studentName: string, transcript: CourseRecord[], studentId: string, gpa: number, hoursDone: number, hoursTotal: number, locale: 'ar' | 'en' = 'ar') => {
    const passedCourses = transcript.filter(c => c.status === 'ناجح' || c.status === 'passed').length;
    const failedCourses = transcript.filter(c => c.status === 'راسب' || c.status === 'failed').length;
    const totalCredits = transcript.filter(c => c.status === 'ناجح' || c.status === 'passed').reduce((sum, c) => sum + c.creditHours, 0);
    
    if (locale === 'en') {
      return `### 📋 Full Academic Transcript for ${studentName}

**Basic Information:**
* **Student ID:** ${studentId}
* **Current GPA:** ${gpa}%
* **Progress:** ${hoursDone}/${hoursTotal} credit hours (${Math.round(hoursDone/hoursTotal*100)}%)
* **Courses Passed:** ${passedCourses} | **Courses Failed:** ${failedCourses}
* **Total Credits Earned:** ${totalCredits} hours

**Course Details:**

${transcript.map((course) => {
  const statusIcon = course.status === 'ناجح' || course.status === 'passed' ? '✅' : course.status === 'راسب' || course.status === 'failed' ? '❌' : '⏳';
  return `${statusIcon} **${course.name}** (${course.code})
   Grade: **${course.grade}** | Credits: ${course.creditHours} | Status: ${course.status}`;
}).join('\n\n')}

**Summary:** You have successfully completed ${passedCourses} course(s) with an overall GPA of **${gpa}%**. Keep up the excellent work!`;
    }

    return `### 📋 كشف العلامات الكامل للطالب ${studentName}

**معلومات أساسية:**
* **الرقم الجامعي:** ${studentId}
* **المعدل التراكمي:** ${gpa}%
* **الإنجاز الأكاديمي:** ${hoursDone}/${hoursTotal} ساعة معتمدة (${Math.round(hoursDone/hoursTotal*100)}%)
* **المواد الناجحة:** ${passedCourses} | **المواد الراسبة:** ${failedCourses}
* **إجمالي الساعات المكتسبة:** ${totalCredits} ساعة

**تفاصيل المواد الدراسية:**

${transcript.map((course) => {
  const statusIcon = course.status === 'ناجح' ? '✅' : course.status === 'راسب' ? '❌' : '⏳';
  return `${statusIcon} **${course.name}** (${course.code})
   التقدير: **${course.grade}** | الساعات: ${course.creditHours} | الحالة: ${course.status}`;
}).join('\n\n')}

**الملخص:** لقد أكملت بنجاح ${passedCourses} مادة(مواد) بمعدل تراكمي **${gpa}%**. الاستمرار بهذا التفوق!`;
  };

  const buildGradeAnalysisResponse = (studentName: string, transcript: CourseRecord[], gpa: number, locale: 'ar' | 'en' = 'ar') => {
    const gradeDistribution: Record<string, number> = {};
    transcript.forEach(course => {
      gradeDistribution[course.grade] = (gradeDistribution[course.grade] || 0) + 1;
    });

    const avgCredits = transcript.reduce((sum, c) => sum + c.creditHours, 0) / transcript.length;
    
    if (locale === 'en') {
      return `### 📊 Grade Analysis & Performance Summary

**Student:** ${studentName}

**Overall GPA:** ${gpa}%
**Average Course Credits:** ${avgCredits.toFixed(1)} hours
**Total Courses:** ${transcript.length}

**Grade Distribution:**
${Object.entries(gradeDistribution).map(([grade, count]) => `* **${grade}**: ${count} course(s)`).join('\n')}

**Academic Status:**
${gpa >= 90 ? '🌟 **EXCELLENT** - Dean\'s List Candidate (GPA ≥ 90%)' : gpa >= 80 ? '⭐ **VERY GOOD** - Strong academic performance (GPA 80-89%)' : gpa >= 70 ? '👍 **GOOD** - Satisfactory performance (GPA 70-79%)' : gpa >= 65 ? '⚠️ **AT RISK** - Academic warning may be issued (GPA 65-69%)' : '🚨 **CRITICAL** - Academic probation (GPA < 65%)'}

**Recommendations:**
${gpa >= 85 ? '✓ Keep maintaining your excellent performance!' : gpa >= 70 ? '→ Focus on improving your grades to reach 80%+' : '→ Seek help from academic advisors and tutoring services'}`;
    }

    return `### 📊 تحليل الأداء الأكاديمي والعلامات

**الطالب:** ${studentName}

**المعدل التراكمي:** ${gpa}%
**متوسط ساعات المادة:** ${avgCredits.toFixed(1)} ساعة
**عدد المواد الكلي:** ${transcript.length}

**توزيع التقديرات:**
${Object.entries(gradeDistribution).map(([grade, count]) => `* **${grade}**: ${count} مادة(مواد)`).join('\n')}

**الوضع الأكاديمي:**
${gpa >= 90 ? '🌟 **ممتاز جداً** - مرشح لوحة الشرف (معدل ≥ 90%)' : gpa >= 80 ? '⭐ **جيد جداً** - أداء أكاديمي قوي (معدل 80-89%)' : gpa >= 70 ? '👍 **جيد** - أداء مرضي (معدل 70-79%)' : gpa >= 65 ? '⚠️ **تحت الملاحظة** - قد يتم إصدار إنذار أكاديمي (معدل 65-69%)' : '🚨 **حرج** - وضع أكاديمي حرج (معدل < 65%)'}

**التوصيات:**
${gpa >= 85 ? '✓ استمر في الحفاظ على أدائك المتميز!' : gpa >= 70 ? '→ ركز على تحسين درجاتك للوصول إلى 80% فما فوق' : '→ اطلب المساعدة من المرشدين الأكاديميين وخدمات التدريس المساعد'}`;
  };

  const isArabicText = (text: string) => /[ء-ي]/.test(text);
  const asLocale = (text: string) => isArabicText(text) ? 'ar' : 'en';
  const buildCourseLocationResponse = (course: CourseSchedule, locale: 'ar' | 'en') => {
    if (locale === 'en') {
      return `### 📍 Lecture Location for ${course.name} (${course.code})

* **Room:** ${course.room}
* **Days:** ${course.days.join(', ')}
* **Time:** ${course.time}
* **Type:** ${course.type}

If you need directions on campus or the next available room, I can help.`;
    }

    return `### 📍 موقع قاعة مادة ${course.name} (${course.code})

* **القاعة:** ${course.room}
* **الأيام:** ${course.days.join('، ')}
* **الوقت:** ${course.time}
* **النوع:** ${course.type}

إذا كنت تريد، يمكنني أيضاً إرشادك إلى خريطة الحرم الجامعي أو مواعيد القاعات التالية.`;
  };

  const buildCoursesTodayResponse = (courses: CourseSchedule[], locale: 'ar' | 'en') => {
    if (locale === 'en') {
      return `### 📅 Today's Registered Courses

${courses.map((course) => `* **${course.name}** (${course.code}) — ${course.time} in ${course.room} (${course.type})`).join('\n')}

If you want, I can also show your full weekly schedule or next exam details.`;
    }

    return `### 📅 موادك المسجلة اليوم

${courses.map((course) => `* **${course.name}** (${course.code}) — ${course.time} في ${course.room} (${course.type})`).join('\n')}

إذا أردت، يمكنني أيضاً عرض الجدول الأسبوعي الكامل أو تفاصيل الامتحان القادم.`;
  };

  const buildNextExamResponse = (exam: ExamRecord, locale: 'ar' | 'en') => {
    if (locale === 'en') {
      return `### 📝 Next Exam

* **Course:** ${exam.courseName} (${exam.courseCode})
* **Date:** ${exam.date}
* **Time:** ${exam.time}
* **Location:** ${exam.location}
* **Exam Type:** ${exam.examType}

Good luck. If you'd like, I can also show the rest of your exam schedule.`;
    }

    return `### 📝 الامتحان القادم

* **المادة:** ${exam.courseName} (${exam.courseCode})
* **التاريخ:** ${exam.date}
* **الوقت:** ${exam.time}
* **الموقع:** ${exam.location}
* **نوع الامتحان:** ${exam.examType}

بالتوفيق. إذا أردت، أستطيع أيضاً عرض بقية جدول الامتحانات.`;
  };

  const buildAnnouncementsResponse = (announcements: Announcement[], locale: 'ar' | 'en') => {
    if (locale === 'en') {
      return `### 🔔 Latest Announcements

${announcements.slice(0, 3).map((item) => `* **${item.title}** (${item.date}) — ${item.body}${item.link ? ` [More](${item.link})` : ''}`).join('\n')}

Need help handling any of these announcements or setting a reminder?`;
    }

    return `### 🔔 أحدث الإعلانات

${announcements.slice(0, 3).map((item) => `* **${item.title}** (${item.date}) — ${item.body}${item.link ? ` [عرض المزيد](${item.link})` : ''}`).join('\n')}

هل تحتاج مساعدة في التعامل مع أي من هذه الإعلانات أو ضبط تذكير؟`;
  };

  const getNextExam = (exams: ExamRecord[]) => {
    const sorted = [...exams].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    return sorted.find((exam) => new Date(exam.date) >= new Date()) || sorted[0] || null;
  };

  const filterCoursesToday = (courses: CourseSchedule[]) => {
    const today = new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(new Date());
    return courses.filter((course) => course.days.some((day) => day.toLowerCase().includes(today.toLowerCase())));
  };

  // Enhanced Multi-Agent Strategy & Knowledge Base
  const aiAgents = {
    academic: { name: 'الوكيل الأكاديمي', role: 'خبير في الخطط الدراسية، المواد، والأنظمة الأكاديمية.' },
    financial: { name: 'الوكيل المالي', role: 'خبير في الرسوم، المنح، وطرق الدفع.' },
    technical: { name: 'الوكيل التقني', role: 'خبير في حل المشاكل التقنية وتنسيق الأنظمة.' }
  };

  const vectorDB = [
    { 
      type: 'academic', 
      tags: ['تسجيل', 'سحب', 'إضافة', 'التسجيل', 'السحب', 'الاضافة'], 
      content: 'تبدأ فترة السحب والإضافة للفصل الدراسي الأول عادةً في مطلع شهر سبتمبر وتستمر لمدة أسبوعين. يمكن للطلبة تسجيل المواد وإدارتها بالكامل من خلال البوابة الأكاديمية الرسمية عبر الرابط: https://reg.ppu.edu' 
    },
    { 
      type: 'academic', 
      tags: ['ريتاج', 'التعليم الالكتروني', 'ritaj', 'منصة', 'المحاضرات'], 
      content: 'منصة ريتاج (Ritaj) للتعليم الإلكتروني هي المنصة المعتمدة في جامعة بوليتكنك فلسطين لمتابعة المحاضرات والواجبات والتواصل الأكاديمي مع المدرسين. رابط الدخول: https://ritaj.ppu.edu' 
    },
    { 
      type: 'colleges', 
      tags: ['تخصصات', 'كليات', 'تخصص', 'كلية', 'القبول', 'برامج'], 
      content: 'تضم جامعة بوليتكنك فلسطين كليات رائدة مثل:\n1. كلية تكنولوجيا المعلومات وهندسة الحاسوب (هندسة حاسوب، علم حاسوب، أمن سيبراني، ذكاء اصطناعي).\n2. كلية الهندسة (ميكانيك، طاقة متجددة، هندسة مدنية، عمارة).\n3. كلية الطب البشري والعلوم الصحية.\n4. كلية العلوم الإدارية ونظم المعلومات.\n5. كلية العلوم التطبيقية وكلية المهن التطبيقية.' 
    },
    { 
      type: 'financial', 
      tags: ['رسوم', 'ساعة', 'مالية', 'قسط', 'دفع', 'البنك'], 
      content: 'سعر الساعة المعتمدة يختلف حسب التخصص؛ فعلى سبيل المثال تخصص هندسة الحاسوب وتكنولوجيا المعلومات يبلغ 45 ديناراً أردنياً للساعة. يمكن غلق وحساب القسط المالي بزيارة خيار الدفع الإلكتروني بالبوابة أو التسديد من خلال قنوات الدفع المعتمدة: تطبيق بنك فلسطين، البنك الإسلامي الفلسطيني، تطبيق PalPay، أو المحفظة الإلكترونية لشركة جوال Jawwal Pay.' 
    },
    { 
      type: 'academic', 
      tags: ['تخرج', 'شرف', 'معدل', 'إنذار', 'راسب', 'ناجح'], 
      content: 'شروط التخرج والوضع الأكاديمي في PPU:\n- يحصل الطالب على مرتبة الشرف إذا كان معدله التراكمي >= 90% ولم يرتكب أي عقوبة مسلكية.\n- يُوضع الطالب تحت الإنذار الأكاديمي إذا قل معدله التراكمي عن 65% في برامج البكالوريوس.\n- متطلبات التخرج تشمل مساقي "مشروع تخرج 1 و 2" واجتياز ساعات التدريب العملي الميداني المقررة (عادةً 90 ساعة عمل للمهن التطبيقية و120 ساعة للبكالوريوس).' 
    },
    { 
      type: 'general', 
      tags: ['مكان', 'خليل', 'تأسيس', 'تاريخ', 'بوليتكنك', 'الجامعة'], 
      content: 'جامعة بوليتكنك فلسطين (PPU) هي جامعة عامة رائدة تقع في مدينة الخليل بالضفة الغربية (الموقع الرئيسي: وادي الهرية، فرع مبنى عين سارة، مبنى العلوم التطبيقية في أبو رمان). تأسست في عام 1978 من قبل رابطة الجامعيين وتعتبر الجامعة التكنولوجية الأولى والأبرز في فلسطين.' 
    },
    { 
      type: 'academic', 
      tags: ['مكتبة', 'بحوث', 'دراسات', 'كتب', 'علمي'], 
      content: 'توفر عمادة البحث العلمي ومكتبة الجامعة الرقمية آلاف المصادر والمراجع العلمية والكتب للطلبة والباحثين. للوصول لبوابة المكتبة والبحث العلمي: https://library.ppu.edu' 
    },
    { 
      type: 'contacts', 
      tags: ['تواصل', 'عنوان', 'هاتف', 'ايميل', 'القبول والتسجيل', 'عمادة', 'اتصال'], 
      content: 'للتواصل مع دائرة القبول والتسجيل في جامعة بوليتكنك فلسطين:\n- البريد الإلكتروني الرسمي: reg@ppu.edu\n- الصفحة الرسمية لعمادة شؤون الطلبة: https://www.ppu.edu/p/ar/student-affairs\n- الهاتف الرئيسي: +970-2-2233050' 
    }
  ];

  // API Routes
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'PPU AI Global Engine Active', version: '4.2.0-Agentic' });
  });

  // Storage for fake DBs (in-memory for prototype)
  const students: Student[] = [
    {
      id: '123456',
      name: 'أحمد محمود',
      major: 'هندسة حاسوب',
      gpa: 88.5,
      hoursDone: 92,
      hoursTotal: 120,
      balance: -180,
      transcript: [
        { code: 'CS201', name: 'هندسة برمجيات متقدمة', grade: 'A', creditHours: 3, status: 'ناجح' },
        { code: 'CS303', name: 'ذكاء اصطناعي', grade: 'B+', creditHours: 3, status: 'ناجح' },
        { code: 'CS315', name: 'أمن المعلومات', grade: 'A-', creditHours: 3, status: 'ناجح' },
        { code: 'CS220', name: 'هياكل بيانات', grade: 'B', creditHours: 3, status: 'ناجح' },
        { code: 'CS401', name: 'مشروع تخرج 1', grade: 'B+', creditHours: 4, status: 'مستمر' }
      ],
      courses: [
        { code: 'CS201', name: 'هندسة برمجيات متقدمة', days: ['Monday', 'Wednesday'], time: '08:00 - 09:30', room: 'B302', type: 'وجاهي' },
        { code: 'CS303', name: 'ذكاء اصطناعي', days: ['Tuesday', 'Thursday'], time: '10:00 - 11:30', room: 'L201', type: 'وجاهي' },
        { code: 'CS220', name: 'هياكل بيانات', days: ['Sunday', 'Wednesday'], time: '13:00 - 14:30', room: 'B203', type: 'مدمج' },
      ],
      exams: [
        { courseCode: 'CS303', courseName: 'ذكاء اصطناعي', date: '2026-06-03', time: '09:00', location: 'قاعة L201', examType: 'نهائي' },
        { courseCode: 'CS220', courseName: 'هياكل بيانات', date: '2026-06-05', time: '11:00', location: 'قاعة B203', examType: 'نصف فصل' },
      ],
      announcements: [
        { id: 'ann-1', title: 'فتح فترة التسجيل الصيفي', category: 'التسجيل', date: '2026-05-20', body: 'تم فتح نافذة التسجيل الصيفي للطلبة المسجلين في الجامعة. يرجى الاطلاع على البوابة للموافقات.', link: 'https://reg.ppu.edu' },
        { id: 'ann-2', title: 'تحضير امتحانات الكلية', category: 'الامتحانات', date: '2026-05-18', body: 'تأكد من رفع التعاريف النهائية وخطة المراجعة لكل مساق قبل يوم الامتحان.' },
        { id: 'ann-3', title: 'خدمات المكتبة المتاحة', category: 'المكتبة', date: '2026-05-15', body: 'المكتبة الرقمية مفتوحة 24/7، ويمكنك الوصول إلى قواعد البيانات العلمية عبر حساب الجامعة.' }
      ],
      notifications: [
        { id: 'note-1', title: 'مستحقات مالية متبقية', expiresAt: '2026-06-01', details: 'يوجد مبلغ 180 دينار أردني مستحق لدفع رسوم التسجيل.' },
        { id: 'note-2', title: 'الموعد النهائي لتسليم المشروع', expiresAt: '2026-05-28', details: 'يرجى تسليم مشروع مادة CS401 قبل الموعد النهائي لتفادي الخصم.' }
      ]
    }
  ];

  const authMiddleware = (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized access.' });
    }

    const token = authHeader.slice(7);
    const userId = verifySessionToken(token);
    if (!userId) {
      return res.status(401).json({ error: 'Invalid or expired session token.' });
    }

    const user = students.find((student) => student.id === userId);
    if (!user) {
      return res.status(401).json({ error: 'User session is no longer valid.' });
    }

    (req as Request & { user: Student }).user = user;
    next();
  };

  app.post('/api/auth/login', (req, res) => {
    const { studentId, password } = req.body;

    if (!studentId || !password) {
      return res.status(400).json({ error: 'Student ID and password are required.' });
    }

    const student = students.find((user) => user.id === studentId);
    if (!student) {
      return res.status(401).json({ error: 'رقم جامعي غير صالح أو كلمة مرور خاطئة.' });
    }

    const token = createSessionToken(student.id);
    return res.json({
      user: { id: student.id, name: student.name, major: student.major, gpa: student.gpa, hoursDone: student.hoursDone, hoursTotal: student.hoursTotal },
      token,
    });
  });

  app.post('/api/auth/logout', authMiddleware, (_req, res) => {
    return res.json({ status: 'logged_out' });
  });

  app.get('/api/auth/me', authMiddleware, (req, res) => {
    const user = (req as Request & { user: Student }).user;
    return res.json({ user });
  });

  app.get('/api/student/transcript', authMiddleware, (req, res) => {
    const user = (req as Request & { user: Student }).user;
    return res.json({ transcript: user.transcript });
  });

  app.get('/api/student/grades/analysis', authMiddleware, (req, res) => {
    const user = (req as Request & { user: Student }).user;
    const gradeDistribution: Record<string, number> = {};
    user.transcript.forEach(course => {
      gradeDistribution[course.grade] = (gradeDistribution[course.grade] || 0) + 1;
    });

    const passedCourses = user.transcript.filter(c => c.status === 'ناجح' || c.status === 'passed').length;
    const failedCourses = user.transcript.filter(c => c.status === 'راسب' || c.status === 'failed').length;
    const totalCredits = user.transcript.filter(c => c.status === 'ناجح' || c.status === 'passed').reduce((sum, c) => sum + c.creditHours, 0);

    return res.json({
      gpa: user.gpa,
      passedCourses,
      failedCourses,
      totalCredits,
      gradeDistribution,
      academicStatus: user.gpa >= 90 ? 'Honor List' : user.gpa >= 80 ? 'Excellent' : user.gpa >= 70 ? 'Good' : user.gpa >= 65 ? 'At Risk' : 'Critical'
    });
  });

  app.get('/api/student/grades/summary', authMiddleware, (req, res) => {
    const user = (req as Request & { user: Student }).user;
    return res.json({
      name: user.name,
      studentId: user.id,
      gpa: user.gpa,
      hoursDone: user.hoursDone,
      hoursTotal: user.hoursTotal,
      progressPercentage: Math.round(user.hoursDone / user.hoursTotal * 100),
      major: user.major,
      transcript: user.transcript
    });
  });

  app.get('/api/student/profile', authMiddleware, (req, res) => {
    const user = (req as Request & { user: Student }).user;
    return res.json({ profile: { id: user.id, name: user.name, major: user.major, gpa: user.gpa, hoursDone: user.hoursDone, hoursTotal: user.hoursTotal, balance: user.balance } });
  });

  app.get('/api/student/courses', authMiddleware, (req, res) => {
    const user = (req as Request & { user: Student }).user;
    return res.json({ courses: user.courses });
  });

  app.get('/api/student/schedule', authMiddleware, (req, res) => {
    const user = (req as Request & { user: Student }).user;
    return res.json({ schedule: user.courses });
  });

  app.get('/api/student/exams', authMiddleware, (req, res) => {
    const user = (req as Request & { user: Student }).user;
    return res.json({ exams: user.exams });
  });

  app.get('/api/student/announcements', authMiddleware, (req, res) => {
    const user = (req as Request & { user: Student }).user;
    return res.json({ announcements: user.announcements });
  });

  app.get('/api/student/notifications', authMiddleware, (req, res) => {
    const user = (req as Request & { user: Student }).user;
    return res.json({ notifications: user.notifications });
  });

  app.get('/api/student/location/:course?', authMiddleware, (req, res) => {
    const user = (req as Request & { user: Student }).user;
    const courseQuery = String(req.params.course || '').trim();
    if (!courseQuery) {
      return res.json({ locationGuide: 'For lecture hall details, provide a course name or code like CS303.' });
    }
    const matchedCourse = user.courses.find((course) => {
      const normalizedCourseName = normalizeText(course.name);
      const normalizedCourseCode = normalizeText(course.code);
      const normalizedQuery = normalizeText(courseQuery);
      return normalizedQuery === normalizedCourseCode || normalizedCourseName.includes(normalizedQuery) || normalizedQuery.includes(normalizedCourseName);
    });

    if (!matchedCourse) {
      return res.status(404).json({ error: 'لم يتم العثور على هذه المادة في جدولك.' });
    }

    return res.json({ location: matchedCourse.room, days: matchedCourse.days, time: matchedCourse.time, course: matchedCourse });
  });

  app.get('/api/student/transcript/:course', authMiddleware, (req, res) => {
    const user = (req as Request & { user: Student }).user;
    const courseQuery = String(req.params.course || '').trim();
    const matchedCourse = user.transcript.find((course) => {
      const normalizedCourseName = normalizeText(course.name);
      const normalizedCourseCode = normalizeText(course.code);
      const normalizedQuery = normalizeText(courseQuery);
      return normalizedQuery === normalizedCourseCode || normalizedCourseName.includes(normalizedQuery) || normalizedQuery.includes(normalizedCourseName);
    });

    if (!matchedCourse) {
      return res.status(404).json({ error: 'لم يتم العثور على المادة المطلوبة في كشف العلامات.' });
    }

    return res.json({ course: matchedCourse });
  });

  app.post('/api/chat/stream', authMiddleware, async (req, res) => {
    const { messages, studentContext } = req.body;
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    try {
      if (!messages || !Array.isArray(messages) || messages.length === 0) {
        res.write(`data: ${JSON.stringify({ error: 'عذراً، لم يتم العثور على أي رسائل للبدء.' })}\n\n`);
        return res.end();
      }

      const lastUserMsg = messages[messages.length - 1].content;
      const ai = getAiInstance();

      // ==========================================
      // Local NLP Fallback Engine (Runs when GEMINI_API_KEY is not set)
      // Simulates high-performance RAG pipeline in code
      // ==========================================
      if (!ai) {
        const currentUser = (req as Request & { user: Student }).user;
        const studentName = currentUser.name;
        const matchedTranscriptCourse = findCourseMatch(lastUserMsg, currentUser.transcript);
        const matchedScheduleCourse = currentUser.courses.find((course) => normalizeText(course.code) === normalizeText(lastUserMsg) || normalizeText(course.name) === normalizeText(lastUserMsg));
        const normMsg = normalizeText(lastUserMsg);
        const locale: 'ar' | 'en' = 'ar'; // Always respond in Arabic
        let responseText = '';

        const gradeKeywords = ['علامة', 'علامات', 'علامتي', 'درجتي', 'تقدير', 'درجة', 'نتيجة', 'كشف', 'gpa', 'grade'];
        const scheduleKeywords = ['جدول', 'اليوم', 'course', 'courses', 'schedule', 'lecture', 'القاعة', 'room', 'class'];
        const examKeywords = ['امتحان', 'exams', 'exam', 'next exam', 'تاريخ الامتحان', 'الامتحان'];
        const announcementKeywords = ['إعلان', 'اعلان', 'announcements', 'announcement', 'news', 'أخبار'];
        const locationKeywords = ['قاعة', 'room', 'where', 'أين', 'مكان', 'hall', 'lecture hall'];
        const financialKeywords = ['رسوم', 'دفع', 'قسط', 'balance', 'سعر الساعة', 'tuition'];

        const isGradeQuery = gradeKeywords.some((term) => normMsg.includes(normalizeText(term)));
        const isScheduleQuery = scheduleKeywords.some((term) => normMsg.includes(normalizeText(term)));
        const isExamQuery = examKeywords.some((term) => normMsg.includes(normalizeText(term)));
        const isAnnouncementQuery = announcementKeywords.some((term) => normMsg.includes(normalizeText(term)));
        const isLocationQuery = locationKeywords.some((term) => normMsg.includes(normalizeText(term)));
        const isFinancialQuery = financialKeywords.some((term) => normMsg.includes(normalizeText(term)));

        if (isGradeQuery && matchedTranscriptCourse) {
          responseText = buildTranscriptResponse(studentName, matchedTranscriptCourse, currentUser.id, currentUser.gpa, locale);
        } else if (isGradeQuery && !matchedTranscriptCourse) {
          // Check if user is asking for full transcript
          const fullTranscriptKeywords = ['كشف', 'كامل', 'full', 'transcript', 'جميع', 'كل'];
          const analysisKeywords = ['تحليل', 'analysis', 'إحصائيات', 'statistics', 'distribution', 'توزيع'];
          
          const isFullTranscriptRequest = fullTranscriptKeywords.some((term) => normMsg.includes(normalizeText(term)));
          const isAnalysisRequest = analysisKeywords.some((term) => normMsg.includes(normalizeText(term)));

          if (isFullTranscriptRequest) {
            responseText = buildFullTranscriptResponse(studentName, currentUser.transcript, currentUser.id, currentUser.gpa, currentUser.hoursDone, currentUser.hoursTotal, locale);
          } else if (isAnalysisRequest) {
            responseText = buildGradeAnalysisResponse(studentName, currentUser.transcript, currentUser.gpa, locale);
          } else {
            responseText = locale === 'en'
              ? `Hello ${studentName}, it seems you asked about grades. You can ask me about:\n* A specific course grade (e.g., "grade CS303")\n* Your full transcript (e.g., "show my full transcript")\n* Grade analysis (e.g., "analyze my grades")\n\nWhat would you like to know?`
              : `أهلاً بك يا **${studentName}**. يبدو أنك تطلب معلومات عن العلامات. يمكنك أن تسأل عن:\n* درجة مادة معينة (مثل: "درجة CS303")\n* كشف العلامات الكامل (مثل: "اعرض كشفي الكامل")\n* تحليل العلامات (مثل: "حلل عليماتي")\n\nماذا تريد أن تعرف؟`;
          }
        } else if (isLocationQuery && currentUser.courses.length > 0) {
          const courseMatch = matchedScheduleCourse || currentUser.courses.find((c) => matchedTranscriptCourse && (normalizeText(c.code) === normalizeText(matchedTranscriptCourse.code) || normalizeText(c.name) === normalizeText(matchedTranscriptCourse.name)));
          if (courseMatch) {
            responseText = buildCourseLocationResponse(courseMatch, locale);
          }
        } else if (isExamQuery) {
          const nextExam = getNextExam(currentUser.exams);
          if (nextExam) {
            responseText = buildNextExamResponse(nextExam, locale);
          } else {
            responseText = locale === 'en'
              ? 'I could not find any upcoming exams in your schedule. Please check with your academic advisor or the exam office.'
              : 'لم أجد أي امتحانات قادمة في جدولك حالياً. يرجى التحقق مع المرشد الأكاديمي أو مكتب الامتحانات.';
          }
        } else if (isAnnouncementQuery) {
          responseText = buildAnnouncementsResponse(currentUser.announcements, locale);
        } else if (isScheduleQuery) {
          const todayCourses = filterCoursesToday(currentUser.courses);
          if (todayCourses.length > 0) {
            responseText = buildCoursesTodayResponse(todayCourses, locale);
          } else {
            responseText = locale === 'en'
              ? 'You do not have any registered courses today. I can still show you your weekly schedule if you want.'
              : 'لا توجد لديك مواد مسجلة لهذا اليوم. يمكنني عرض جدولك الأسبوعي إذا رغبت.';
          }
        } else if (isFinancialQuery) {
          responseText = locale === 'en'
            ? `### 💳 Tuition & Financial Summary

* **Current Balance:** ${currentUser.balance} JOD
* **Completed Credits:** ${currentUser.hoursDone} / ${currentUser.hoursTotal}
* **GPA:** ${currentUser.gpa}%

If you need payment links or installment guidance, I can provide the official university channels.`
            : `### 💳 ملخص مالي وأكاديمي

* **الرصيد الحالي:** ${currentUser.balance} دينار أردني
* **الساعات المكتملة:** ${currentUser.hoursDone} / ${currentUser.hoursTotal}
* **المعدل التراكمي:** ${currentUser.gpa}%

إذا أردت، يمكنني تقديم روابط الدفع الرسمية أو إرشادك حول التقسيط.`;
        } else if (normMsg.includes('شرف') || normMsg.includes('انذار') || normMsg.includes('معدل') || normMsg.includes('امتياز') || normMsg.includes('تفوق')) {
          responseText = `### 🎓 شروط مرتبة الشرف والوضع الأكاديمي - جامعة بوليتكنك فلسطين

أهلاً بك يا **${studentName}**، يسعدني جداً إجابتك بالتفصيل حول لوائح التفوق والإنذار الأكاديمي المعتمدة رسمياً في جامعة البوليتكنك:

#### 1️⃣ لوحة مرتبة الشرف (Honor List)
لكي يتم تكريمك وإدارج اسمك في لوحة شرف الجامعة، يجب استيفاء المحدِّدات والشروط التالية:
* **المعدل التراكمي:** يجب ألا يقل المعدل التراكمي العام عن **90%** بتقدير "متميز".
* **العبء الدراسي:** يجب أن يكون الطالب مسجلاً للحد الأدنى من الساعات المعتمدة في ذلك الفصل (لا يقل عن 12 ساعة معتمدة كحد أدنى).
* **السلوك الأكاديمي:** خلو السجل الدراسي تماماً من أي عقوبة انضباطية، تنبيهية أو مسلكية طوال فترة الدراسة.

#### 2️⃣ نظام الإنذار الأكاديمي (Academic Warning)
يوضع الطالب تحت طائلة الإنذار الأكاديمي في الحالات التالية:
* إذا قلَّ المعدل التراكمي العام عن **65%** لطلبة البكالوريوس في أي فصل دراسي اعتيادي (باستثناء الفصل الأول للالتحاق بالجامعة).
* يُمنح الطالب فترة سماح أقصاها فصلين دراسيين متتاليين لرفع معدله التراكمي إلى 65% فما فوق من أجل إزالة الإنذار بشكل تلقائي.
* **النتيجة:** في حال استمرار تدني المعدل دون 65% بعد انتهاء المهلة، تفصل الجامعة الطالب أكاديمياً من تخصصه الحالي مع فرصة التحويل لكليات أخرى أو مستويات مهنية مساندة.

---

### 📊 جدول تحديد مستويات التحصيل والإنذارات:
| التقييم الأكاديمي | نطاق المعدل التراكمي | الإجراءات والمزايا المترتبة |
| :--- | :---: | :--- |
| **مراتب الشرف والتميز** | **\`>= 90%\`** | تكريم رسمي من عمادة شؤون الطلاب + شهادة تقديرية |
| **وضع أكاديمي نشط وممتاز** | **\`70% - 89.9%\`** | متابعة الخطة الدراسية الاعتيادية بنجاح |
| **وضع مقبول وتحت الملاحظة** | **\`65% - 69.9%\`** | إرشاد توجيهي مكثف لتلافي الدخول في منطقة الإنذار |
| **تحت الإنذار الأكاديمي** | **\`< 65%\`** | تحديد سقف التسجيل الأقصى بـ **12 ساعة** لرفع المعدل |

💡 **نصيحة لإرشادك المالي والأكاديمي:** يرجى الحرص على التواصل مع مرشدك الأكاديمي الحالي **د. عماد الخطيب** لمتابعة خطتك والمحافظة على تفوقك ومعدلك المتميز الحالي البالغ **${currentUser.gpa}%**.

 هل تود التعرف على كيفية احتساب المعدلات الفصلية الحالية أو طريقة فتح رزمة السحب والإضافة؟`;
        } else if (normMsg.includes('تسجيل') || normMsg.includes('سحب') || normMsg.includes('اضافه') || normMsg.includes('مواد') || normMsg.includes('قرر')) {
          responseText = `### 📝 دليل بوابة التسجيل الإلكتروني والسحب والإضافة - جامعة بوليتكنك فلسطين

أهلاً بك يا **${studentName}**، إليك كافة الإرشادات لفتح رزم ومساقات التسجيل الأكاديمي لهذا الفصل:

#### 🏛️ آلية التسجيل الأكاديمي الإلكتروني
تتم العملية بالكامل بطريقة مترابطة مع السيرفر الرئيسي للجامعة عبر الخطوات التالية:
1. **شحن رصيد الطالب:** سداد الحد الأدنى من رسوم القسط للحصول على "حق التسجيل" تلقائياً.
2. **استشارة المرشد:** الاتفاق مع المرشد الأكاديمي (د. عماد الخطيب) لاعتماد فتح الرغبات والمساقات.
3. **الدخول للبوابة الموحدة:** زيارة [بوابة التسجيل الإلكتروني](https://reg.ppu.edu) لترتيب الجدول الأسبوعي.

#### ⏱️ فترات السحب والإضافة والتعليم المدمج
* **التوقيت:** تعقد فترة السحب والإضافة الرسمية مع انطلاق كل فصل دراسي، وتستمر عادةً لمدة تتراوح بين **10 إلى 14 يوماً** من تاريخ بدء التدريس الرسمي.
* **نظام التنسيق مدمج:** المحاضرات واللقاءات التفاعلية أو المواد الإلكترونية المساندة يتم إدارتها ورفع التكليفات والامتحانات القصيرة لها بالكامل من خلال منصة [ريتاج (Ritaj) للتعليم الإلكتروني](https://ritaj.ppu.edu).

---

### 🔗 الروابط الأكاديمية والاتصالات المعتمدة:
* 🌐 **رابط بوابة القبول والتسجيل:** [reg.ppu.edu](https://reg.ppu.edu)
* 📬 **البريد الإلكتروني للقبول والتسجيل:** reg@ppu.edu
* 💻 **بوابة ريتاج المعتمدة للتعليم العالي:** [ritaj.ppu.edu](https://ritaj.ppu.edu)

 هل ترغب in تتبع أو فحص الساعات المتبقية لك ضمن الخطة الدراسية لإضافتها في رزمتك؟`;
        } else if (normMsg.includes('سعر') || normMsg.includes('ساعه') || normMsg.includes('قسط') || normMsg.includes('دفع') || normMsg.includes('مالي') || normMsg.includes('رسوم') || normMsg.includes('بنك') || normMsg.includes('تسديد')) {
          responseText = `### 💳 الدليل المالي: سعر الساعات، أقساط المواد ومنافذ الدفع الإلكتروني المعتمدة

مرحباً بك يا **${studentName}**، إليك المعلومات المالية الرسمية الدقيقة الصادرة عن عمادة شؤون الطلاب والمالية بجامعة البوليتكنك:

#### 📊 أسعار الساعات الدراسية المعتمدة بالتخصصات:
* **تخصص هندسة الحاسوب وتكنولوجيا المعلومات:** يبلغ سعر الساعة **45 ديناراً أردنياً (45 JD)** للمساقات النظرية.
* **تخصص تكنولوجيا أمن المعلومات والشبكات:** يبلغ سعر الساعة **40 ديناراً أردنياً (40 JD)**.
* **باقي مساقات الكليات الهندسية والطبية:** تتراوح بين **50 إلى 80 ديناراً أردنياً** حسب نوع المساق والمختبر.

#### 🏛️ قنوات التسديد المالي والسريع المتاحة لطلاب بوليتكنك فلسطين:
تربط الجامعة حسابات الطلبة بسيرفرات دفع ذكية لمعالجة الأقساط بشكل لحظي وفوري من خلال المنافذ التالية:
1. **تطبيقات البنوك الفورية:** تطبيق بنك فلسطين (الدفع السريع لجامعة بوليتكنك فلسطين)، والبنك الإسلامي الفلسطيني.
2. **محفظة جوال باي (Jawwal Pay):** للدفع عن طريق الهاتف المحمول مباشرة ودون رسوم إضافية.
3. **نقاط بال باي (PalPay):** المتوفرة في كافة مدن الضفة الغربية وقطاع غزة للسداد الفوري.

---

### 🔎 ملخص سريع للبيانات المالية من ملفك الأكاديمي:
* **عدد الساعات المسجلة رسمياً:** 15 ساعة معتمدة.
* **المدفوع الكلي:** 720 دينار أردني.
* **المستحقات المتبقية للتسديد النهائي:** **180 دينار أردني (180 JD)** فقط.

 هل ترغب في الاستفسار عن تفاصيل ومواعيد تقسيط الرسوم الدراسية أو شروط تقديم قروض صندوق طالب فلسطين؟`;
        } else if (normMsg.includes('ريتاج') || normMsg.includes('محاضرات') || normMsg.includes('غرف') || normMsg.includes('قاعات') || normMsg.includes('اين') || normMsg.includes('مواقع') || normMsg.includes('مبنى') || normMsg.includes('مجمع')) {
          responseText = `### 🏛️ توزيع الغرف الدراسية وقاعات المحاضرات ومنصة ريتاج (Ritaj Portal)

أهلاً بك يا **${studentName}**، يسرني تزويدك بالمواقع الجغرافية لكليات ومباني بوليتكنك فلسطين وكيفية استخدام النظام التعليمي:

#### 🎛️ دليل منصة ريتاج (Ritaj Portal)
منصة ريتاج هي المنصة الإدارية والأكاديمية الموحدة لطلبة بوليتكنك فلسطين، وتُستخدم من أجل:
* **التعليم:** الاطلاع على المساقات الإلكترونية والمحاضرات مدمجة.
* **الاتصال وبطاقة الحضور والغياب:** الاطلاع على الحضور، غيابات المساقات، العلامات الفصلية ومحاورة مدرسي المواد.
* **رابط الوصول المباشر:** [portal.ritaj.ppu.edu](https://ritaj.ppu.edu)

#### 🏢 توزيع قاعات التدريس والمجمعات الأساسية بالخليل:
تتوزع كليات جامعة بوليتكنك فلسطين على مجمعات جغرافية حديثة لتيسير الحركة:
1. **حرم وادي الهرية (الموقع الرئيسي):** ويحتوي على **كلية تكنولوجيا المعلومات وهندسة الحاسوب**، كلية الهندسة والمباني الإدارية الرئيسية الكبرى.
   * قاعات حرف (B) مثل **B302** وقاعات مختبرات الحاسوب مثل **L201** تقع جميعاً في هذا الحرم.
2. **حرم أبو رمان:** يضم كليات العلوم التطبيقية والبحث العلمي بالإضافة لعمادة الدراسات العليا.
3. **فرع عين سارة:** يضم تخصصات كلية المهن التطبيقية والتعليم العالي المستمر.

---

### 📅 جدول محاضراتك اليومية للرجوع السريع:
| اسم المساق الدراسي | توقيت اللقاء | نوع المحاضرة | مكان وقاعة الانعقاد والترميز |
| :--- | :---: | :---: | :--- |
| **ذكاء اصطناعي (مختبر)** | \`10:00 - 11:30\` | وجاهي | مختبرات تكنولوجيا المعلومات **L201** |
| **أخلاقيات المهنة** | \`13:00 - 14:00\` | مدمج | التعليم التفاعلي عبر بوابة ريتاج |

 هل تريد استخراج جدول بقية أيام الأسبوع الدراسي والمشرفين الأكاديميين للمساقات الخاصة بك؟`;
        } else {
          responseText = `### 👋 مرحباً بك في البوابة الأكاديمية الذكية لجامعة بوليتكنك فلسطين (PPU RAG NLP Core)

أهلاً وسهلاً بك يا **${studentName}** في منصتك الاستشارية الأكاديمية والمالية الشاملة.

أنا **مساعد الذكاء الاصطناعي المركزي لجامعة البوليتكنك**، مصمم خصيصاً لمساعدتك وإرشادك طوال مسيرتك الجامعية بفضل قاعدة بياناتنا المتكاملة (RAG Engine).

يمكنك سؤالي مباشرة عن الأمور التالية وسأجيبك بدقة وحقائق فورية:
* 📝 **إجراءات التسجيل الأكاديمي:** بخصوص عمليات السحب والإضافة والمساقات المطروحة عبر [بوابة التسجيل](https://reg.ppu.edu).
* 💳 **المدفوعات والأمور المالية:** سعر الساعات الأكاديمية (مثل هندسة الحاسوب بـ 45 ديناراً) وكيفية دفع المستحقات عبر حسابات بنك فلسطين، PalPay أو جوال باي.
* 🏛️ **ريتاج وتوزيع القاعات:** سبل الوصول الفوري لطلب تتبع غياباتك، جدولك، والتواصل عبر [ريتاج (Ritaj)](https://ritaj.ppu.edu)، وتحديد مواقع القاعات والمختبرات (مثل مبنى B302 أو مختبر L201 في وادي الهرية).
* 🎓 **التفوق والإنذارات الأكاديمية:** متطلبات لوائح مرتبة الشرف (معدل >= 90%) وضوابط الإنذار الأكاديمي (معدل < 65%).

**المعالجة الطبيعية للغة (Core Python NLP Simulation):**
المساعد مدعوم بخوارزميات ذكية لمعالجة الكلمات وتوجيهها لتطابق اللوائح الرسمية لجامعة بوليتكنك فلسطين كبديل محلي ممتاز وخارق الذكاء.

👉 **تفضل بطرح أي سؤال أو استفسار يخص دراستك، وسأقوم بالإجابة الفورية وتوجيهك خطوة بخطوة مدمجة بالروابط الرسمية الموثوقة!**`;
        }

        // Stream the response to client with chunk size and delay for maximum natural immersion!
        let index = 0;
        const chunkSize = 16; 
        while (index < responseText.length) {
          const chunk = responseText.substring(index, index + chunkSize);
          res.write(`data: ${JSON.stringify({ text: chunk })}\n\n`);
          index += chunkSize;
          await new Promise(resolve => setTimeout(resolve, 30));
        }

        res.write('data: [DONE]\n\n');
        return res.end();
      }

      // ==========================================
      // Live Gemini Engine (Runs when GEMINI_API_KEY is active)
      // ==========================================
      let selectedAgent = aiAgents.academic;
      if (lastUserMsg.includes('دفع') || lastUserMsg.includes('مال') || lastUserMsg.includes('رسوم')) {
        selectedAgent = aiAgents.financial;
      } else if (lastUserMsg.includes('مشكلة') || lastUserMsg.includes('تطبيق') || lastUserMsg.includes('تقني')) {
        selectedAgent = aiAgents.technical;
      }

      // Semantic Search Over VectorDB
      const normalizedMsg = lastUserMsg.toLowerCase();
      const relevantDocs = vectorDB
        .filter(doc => {
          return doc.tags.some(tag => normalizedMsg.includes(tag.toLowerCase())) ||
                 normalizedMsg.includes(doc.type) ||
                 doc.content.toLowerCase().includes(normalizedMsg);
        })
        .map(doc => doc.content)
        .join('\n- ');

      const systemPrompt = `أنت هو "PPU Avatar" - نظام الذكاء الاصطناعي المركزي والذكي لجامعة بوليتكنك فلسطين.
أنت الآن تعمل بهوية: [${selectedAgent.name}] ومهمتك: [${selectedAgent.role}].

سياق الطالب الحالي (Context):
${studentContext ? JSON.stringify(studentContext) : 'طالب زائر'}

بيانات مسترجعة وحقائق موثقة (RAG Knowledge & Official Sources):
- ${relevantDocs || 'استخدم معرفتك العامة والعميقة عن جامعة بوليتكنك فلسطين بكافة كلياتها وأنظمتها، وركز على توجيه الطالب بشكل ودود ومحترف.'}

أسلوب الرد العبقري والمصدر الموثوق:
1. استجابة سريعة جداً وحاسمة تعتمد بالدرجة الأولى على البيانات المسترجعة (RAG).
2. استخدم تنسيق Markdown الفاخر (عناوين، قوائم نقطية، جداول مريحة، ونصوص بارزة).
3. خاطب الطالب دائماً باسمه الشخصي إذا توفر في سياق الطالب (Context) لإضفاء طابع شخصي لطيف.
4. **هام جداً**: قم بتضمين مصادر وروابط صالحة للنقر بدقة متناهية من البيانات المتاحة (مثال: [بوابة التسجيل الأكاديمية](https://reg.ppu.edu) أو [منصة ريتاج للتعليم الإلكتروني](https://ritaj.ppu.edu) أو هاتف أو إيميل التسجيل reg@ppu.edu) لمساعدة الطالب في الوصول الفوري للخدمة.
5. يجب أن يدعم كلامك التحليل الذكي للأسئلة وتقديم إجابات غنية بالنصائح الأكاديمية والعملية.
6. في نهاية الرد، اقترح خدمة أكاديمية أو ميزة متصلة ذات صلة (مثلاً: "هل تريد البدء في مراجعة جدولك الدراسي اليوم؟" أو "هل تود استكشاف الرسوم والمستحقات؟").`;

      const formattedMessages = messages.map((m: any) => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }]
      }));

      const responseStream = await ai.models.generateContentStream({
        model: 'gemini-3.5-flash',
        contents: formattedMessages,
        config: {
           systemInstruction: { parts: [{ text: systemPrompt }] },
           temperature: 0.6,
        },
      });

      for await (const chunk of responseStream) {
        res.write(`data: ${JSON.stringify({ text: chunk.text })}\n\n`);
      }
      
      res.write('data: [DONE]\n\n');
      res.end();
    } catch (error: any) {
      console.error('Core AI Error:', error);
      res.write(`data: ${JSON.stringify({ error: error.message })}\n\n`);
      res.end();
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Enterprise API Server running on port ${PORT}`);
  });
}

startServer();
