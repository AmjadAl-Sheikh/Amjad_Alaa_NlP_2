/**
 * QUICK TEST FILE - Test the new spell checker and intent detector
 * 
 * Run this with: npx tsx test-accuracy.ts
 * Or: node -r tsx test-accuracy.ts
 */

import { spellChecker } from './lib/spellChecker';
import { enhancedIntentDetector } from './lib/enhancedIntentDetector';

console.log('\n' + '='.repeat(60));
console.log('🧪 CHATBOT ACCURACY TEST SUITE');
console.log('='.repeat(60));

// ============================================
// TEST 1: Spell Correction
// ============================================
console.log('\n📝 TEST 1: Spell Correction (Arabic)');
console.log('-'.repeat(60));

const arabicTestCases = [
  { typo: 'علامه', expected: 'علامة' },
  { typo: 'اضافه', expected: 'إضافة' },
  { typo: 'امتحان', expected: 'امتحان' },
  { typo: 'تسجيل', expected: 'تسجيل' },
  { typo: 'رسوم', expected: 'رسوم' },
  { typo: 'درجات', expected: 'درجات' },
  { typo: 'جدول', expected: 'جدول' },
];

let arabicCorrect = 0;
for (const testCase of arabicTestCases) {
  const corrected = spellChecker.correctText(testCase.typo);
  const isCorrect = corrected.toLowerCase().includes(testCase.expected.toLowerCase());
  const status = isCorrect ? '✅' : '❌';
  console.log(`${status} "${testCase.typo}" → "${corrected}"`);
  if (isCorrect) arabicCorrect++;
}
console.log(`✨ Arabic Corrections: ${arabicCorrect}/${arabicTestCases.length}`);

// ============================================
// TEST 2: English Spell Correction
// ============================================
console.log('\n📝 TEST 2: Spell Correction (English)');
console.log('-'.repeat(60));

const englishTestCases = [
  { typo: 'grads', expected: 'grade' },
  { typo: 'examn', expected: 'exam' },
  { typo: 'schedul', expected: 'schedule' },
  { typo: 'resister', expected: 'register' },
  { typo: 'tuton', expected: 'tuition' },
];

let englishCorrect = 0;
for (const testCase of englishTestCases) {
  const corrected = spellChecker.correctText(testCase.typo);
  const isCorrect = corrected.toLowerCase().includes(testCase.expected.toLowerCase());
  const status = isCorrect ? '✅' : '❌';
  console.log(`${status} "${testCase.typo}" → "${corrected}"`);
  if (isCorrect) englishCorrect++;
}
console.log(`✨ English Corrections: ${englishCorrect}/${englishTestCases.length}`);

// ============================================
// TEST 3: Intent Detection
// ============================================
console.log('\n🎯 TEST 3: Intent Detection (Arabic)');
console.log('-'.repeat(60));

const arabicIntentTests = [
  { query: 'ايش علاماتي؟', expectedIntent: 'grades' },
  { query: 'عطيني جدول اليوم', expectedIntent: 'schedule' },
  { query: 'ابدي اضيف مواد', expectedIntent: 'registration' },
  { query: 'متى الامتحان؟', expectedIntent: 'exams' },
  { query: 'أين القاعة؟', expectedIntent: 'location' },
  { query: 'ايش الرسوم؟', expectedIntent: 'financial' },
  { query: 'في إعلانات جديدة؟', expectedIntent: 'announcements' },
];

let arabicIntentsCorrect = 0;
for (const test of arabicIntentTests) {
  const result = enhancedIntentDetector.detect(test.query, []);
  const isCorrect = result.category === test.expectedIntent;
  const status = isCorrect ? '✅' : '❌';
  console.log(`${status} "${test.query}"`);
  console.log(`   → Detected: ${result.category} (${(result.confidence * 100).toFixed(0)}%)`);
  console.log(`   → Expected: ${test.expectedIntent}`);
  if (isCorrect) arabicIntentsCorrect++;
  if (result.correctedText !== test.query) {
    console.log(`   → Corrected: "${result.correctedText}"`);
  }
}
console.log(`✨ Arabic Intent Detection: ${arabicIntentsCorrect}/${arabicIntentTests.length}`);

// ============================================
// TEST 4: Intent Detection with Typos
// ============================================
console.log('\n🎯 TEST 4: Intent Detection with Typos');
console.log('-'.repeat(60));

const typoIntentTests = [
  { query: 'ايش درجاتي بالمادة؟', expectedIntent: 'grades', hasTypo: true },
  { query: 'ابدي اسحب مادة', expectedIntent: 'registration', hasTypo: true },
  { query: 'جدول امتحاناتي', expectedIntent: 'exams', hasTypo: false },
  { query: 'ايش رسوم الساعة', expectedIntent: 'financial', hasTypo: true },
];

let typoIntentsCorrect = 0;
for (const test of typoIntentTests) {
  const result = enhancedIntentDetector.detect(test.query, []);
  const isCorrect = result.category === test.expectedIntent;
  const status = isCorrect ? '✅' : '❌';
  console.log(`${status} "${test.query}"`);
  console.log(`   → Detected: ${result.category} (${(result.confidence * 100).toFixed(0)}%)`);
  console.log(`   → Correction: ${result.correctedText}`);
  if (isCorrect) typoIntentsCorrect++;
}
console.log(`✨ Typo Intent Detection: ${typoIntentsCorrect}/${typoIntentTests.length}`);

// ============================================
// TEST 5: Confidence Scores
// ============================================
console.log('\n📊 TEST 5: Confidence Scores Analysis');
console.log('-'.repeat(60));

const confidenceTests = [
  'ايش علاماتي',                    // Very clear
  'درجات',                         // Clear
  'حاجة ما فهمتها',               // Unclear
  'hello',                         // English unclear
  'what are my grades',           // English clear
];

for (const query of confidenceTests) {
  const result = enhancedIntentDetector.detect(query, []);
  const confidenceLevel = result.confidence > 0.8 ? '🟢 High' : 
                         result.confidence > 0.5 ? '🟡 Medium' : 
                         '🔴 Low';
  console.log(`"${query}"`);
  console.log(`   → Intent: ${result.category}, Confidence: ${confidenceLevel} (${(result.confidence * 100).toFixed(0)}%)`);
}

// ============================================
// TEST 6: Fuzzy Matching
// ============================================
console.log('\n🔤 TEST 6: Fuzzy Matching');
console.log('-'.repeat(60));

const similarityTests = [
  { word1: 'علامة', word2: 'علامه', expectedHigh: true },
  { word1: 'درجات', word2: 'درجه', expectedHigh: true },
  { word1: 'امتحان', word2: 'امتحن', expectedHigh: true },
  { word1: 'قاعة', word2: 'قاعه', expectedHigh: true },
];

for (const test of similarityTests) {
  const similarity = spellChecker.similarity(test.word1, test.word2);
  const isHighSimilarity = similarity > 0.7;
  const status = isHighSimilarity === test.expectedHigh ? '✅' : '❌';
  console.log(`${status} "${test.word1}" ↔ "${test.word2}": ${(similarity * 100).toFixed(0)}% similar`);
}

// ============================================
// SUMMARY REPORT
// ============================================
console.log('\n' + '='.repeat(60));
console.log('📈 TEST SUMMARY REPORT');
console.log('='.repeat(60));

const totalTests = arabicTestCases.length + englishTestCases.length + 
                   arabicIntentTests.length + typoIntentTests.length;
const totalPassed = arabicCorrect + englishCorrect + arabicIntentsCorrect + typoIntentsCorrect;

console.log(`
✅ Spell Correction (Arabic):     ${arabicCorrect}/${arabicTestCases.length}
✅ Spell Correction (English):    ${englishCorrect}/${englishTestCases.length}
✅ Intent Detection (Arabic):     ${arabicIntentsCorrect}/${arabicIntentTests.length}
✅ Intent Detection (with Typos): ${typoIntentsCorrect}/${typoIntentTests.length}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 OVERALL ACCURACY: ${totalPassed}/${totalTests} (${(totalPassed/totalTests*100).toFixed(1)}%)
`);

console.log('\n💡 RECOMMENDATIONS:');
if (totalPassed / totalTests > 0.9) {
  console.log('   ✅ Excellent! The system is ready for production.');
} else if (totalPassed / totalTests > 0.75) {
  console.log('   ⚠️  Good, but could be improved. Review failed cases.');
} else {
  console.log('   ❌ Needs improvement. Check configuration and thresholds.');
}

console.log('\n' + '='.repeat(60));
console.log('✨ Test Complete!');
console.log('='.repeat(60) + '\n');
