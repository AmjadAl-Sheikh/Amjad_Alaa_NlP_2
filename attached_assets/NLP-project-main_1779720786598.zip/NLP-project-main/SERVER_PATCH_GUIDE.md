/**
 * PATCH GUIDE FOR server.ts
 * Step-by-step instructions for integrating the new accuracy modules
 * WITHOUT breaking existing functionality
 */

// ============================================
// STEP 1: ADD THESE IMPORTS TO THE TOP
// ============================================

// LOCATE THESE EXISTING IMPORTS (around line 1-10):
import express, { type Request, type Response, type NextFunction } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { createHmac } from 'crypto';
import IntentDetector from './lib/intentDetection';          // EXISTING
import ResponseGenerator from './lib/responseGenerator';    // EXISTING
import ContextManager from './lib/contextManager';          // EXISTING

// ADD THESE NEW IMPORTS AFTER THE EXISTING ONES:
import { spellChecker } from './lib/spellChecker';           // 🆕 NEW
import { enhancedIntentDetector } from './lib/enhancedIntentDetector';  // 🆕 NEW
import { advancedContextManager } from './lib/advancedContextManager';  // 🆕 NEW

// ============================================
// STEP 2: FIND THIS SECTION (around line 584)
// ============================================

app.post('/api/chat/stream', authMiddleware, async (req, res) => {
  const { messages, studentContext } = req.body;
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  try {
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      res.write(`data: ${JSON.stringify({ error: 'عذراً، لم يتم العثور على أي رسائل للبدء.' })}\n\n`);
      return res.end();
    }

    const lastUserMsg = messages[messages.length - 1].content;
    const ai = getAiInstance();

// ============================================
// STEP 3: ADD THIS NEW CODE BLOCK AFTER "const lastUserMsg"
// ============================================

    // 🆕 SPELL CHECKING & ENHANCED INTENT DETECTION
    const correctedMessage = spellChecker.correctText(lastUserMsg);
    const spellingCorrected = correctedMessage !== lastUserMsg;

    if (spellingCorrected && process.env.DEBUG_CHATBOT === 'true') {
      console.log(`✏️ Spell Correction: "${lastUserMsg}" → "${correctedMessage}"`);
    }

    // Initialize session for context tracking
    const sessionId = `session_${(req as any).user.id}_${Date.now()}`;
    const context = advancedContextManager.getOrCreateContext(sessionId, {
      id: (req as any).user.id,
      name: (req as any).user.name,
      preferredLanguage: studentContext?.preferredLanguage
    });

    // Enhanced intent detection with fuzzy matching
    const intentResult = enhancedIntentDetector.detect(correctedMessage, []);
    
    if (process.env.DEBUG_CHATBOT === 'true') {
      console.log(`🎯 Intent: ${intentResult.category} (${(intentResult.confidence * 100).toFixed(1)}%)`);
      if (intentResult.fuzzyMatches.length > 0) {
        console.log(`   Fuzzy matches: ${intentResult.fuzzyMatches.map(m => `${m.keyword} (${(m.similarity * 100).toFixed(0)}%)`).join(', ')}`);
      }
    }

// ============================================
// STEP 4: MODIFY THE MESSAGE PROCESSING
// ============================================

    // Use correctedMessage instead of lastUserMsg for all processing
    // BEFORE:
    // const normMsg = normalizeText(lastUserMsg);
    
    // AFTER:
    const normMsg = normalizeText(correctedMessage);  // 🆕 USE CORRECTED MESSAGE

// ============================================
// STEP 5: ENHANCE INTENT DETECTION SECTION
// ============================================

    // Replace the existing keyword matching section with this:
    
    // ❌ OLD CODE (KEEP FOR REFERENCE):
    // const gradeKeywords = ['علامة', 'علامات', 'علامتي', 'درجتي', ...];
    // const isGradeQuery = gradeKeywords.some((term) => normMsg.includes(normalizeText(term)));

    // ✅ NEW CODE (REPLACE WITH):
    const isGradeQuery = intentResult.category === 'grades' || 
                        gradeKeywords.some((term) => normMsg.includes(normalizeText(term)));
    
    const isScheduleQuery = intentResult.category === 'schedule' || 
                           scheduleKeywords.some((term) => normMsg.includes(normalizeText(term)));
    
    const isExamQuery = intentResult.category === 'exams' || 
                       examKeywords.some((term) => normMsg.includes(normalizeText(term)));
    
    const isAnnouncementQuery = intentResult.category === 'announcements' || 
                               announcementKeywords.some((term) => normMsg.includes(normalizeText(term)));
    
    const isLocationQuery = intentResult.category === 'location' || 
                           locationKeywords.some((term) => normMsg.includes(normalizeText(term)));
    
    const isFinancialQuery = intentResult.category === 'financial' || 
                            financialKeywords.some((term) => normMsg.includes(normalizeText(term)));

// ============================================
// STEP 6: ADD METADATA TO RESPONSES
// ============================================

    // When sending responses, include confidence metadata:
    res.write(`data: ${JSON.stringify({ 
      text: responseText,
      // 🆕 ADD THESE NEW FIELDS:
      _metadata: {
        intent: intentResult.category,
        confidence: intentResult.confidence,
        corrected: spellingCorrected,
        originalMessage: lastUserMsg,
        correctedMessage: correctedMessage
      }
    })}\n\n`);

// ============================================
// STEP 7: ADD THESE TWO NEW ENDPOINTS
// ============================================

// Add at the end of the file, before app.listen():

app.post('/api/debug/analyze-message', authMiddleware, (req: any, res: any) => {
  const { message } = req.body;
  
  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }

  const corrected = spellChecker.correctText(message);
  const intent = enhancedIntentDetector.detect(message, []);
  const context = advancedContextManager.analyzeSemanticContext(message, `test_session_${Date.now()}`);

  res.json({
    original: message,
    corrected: corrected,
    spellingCorrected: corrected !== message,
    intent: {
      category: intent.category,
      confidence: intent.confidence,
      keywords: intent.keywords,
      matchedKeywords: intent.matchedKeywords,
      fuzzyMatches: intent.fuzzyMatches,
      reasoning: intent.reasoning,
      subIntents: intent.subIntents
    },
    context: {
      contextScore: context.contextScore,
      suggestedContext: context.suggestedContext,
      relatedPreviousMessages: context.relatedPreviousMessages.length
    }
  });
});

// Analytics endpoint
let analyticsData = {
  totalRequests: 0,
  successfulIntentDetections: 0,
  spellingCorrections: 0,
  lowConfidenceQueries: 0,
  averageConfidence: 0,
  confidenceScores: [] as number[]
};

app.get('/api/analytics/chatbot', (req: any, res: any) => {
  const avgConfidence = analyticsData.confidenceScores.length > 0 
    ? analyticsData.confidenceScores.reduce((a, b) => a + b, 0) / analyticsData.confidenceScores.length
    : 0;

  res.json({
    totalRequests: analyticsData.totalRequests,
    accuracyPercentage: (analyticsData.successfulIntentDetections / analyticsData.totalRequests * 100 || 0).toFixed(2),
    spellingCorrections: analyticsData.spellingCorrections,
    lowConfidenceQueries: analyticsData.lowConfidenceQueries,
    averageConfidence: avgConfidence.toFixed(2)
  });
});

// ============================================
// STEP 8: TRACK ANALYTICS IN CHAT HANDLER
// ============================================

// Inside the try block of /api/chat/stream, after intent detection:

analyticsData.totalRequests++;
if (intentResult.confidence > 0.75) {
  analyticsData.successfulIntentDetections++;
}
if (spellingCorrected) {
  analyticsData.spellingCorrections++;
}
if (intentResult.confidence < 0.5) {
  analyticsData.lowConfidenceQueries++;
}
analyticsData.confidenceScores.push(intentResult.confidence);
if (analyticsData.confidenceScores.length > 1000) {
  analyticsData.confidenceScores = analyticsData.confidenceScores.slice(-1000);
}

// ============================================
// SUMMARY OF CHANGES
// ============================================

/*
✅ 3 new imports added
✅ Spell checking applied to input
✅ Enhanced intent detection used
✅ Context manager initialized
✅ All existing functionality preserved
✅ Corrected text used for processing
✅ Metadata added to responses
✅ Debug endpoint added
✅ Analytics tracking added

The new system works alongside the existing code:
- Existing keyword matching still works (as fallback)
- Enhanced intent detection improves accuracy
- Spell correction handles typos automatically
- Context manager enables better follow-ups
- Debug endpoints help with testing
- Analytics track performance

NO BREAKING CHANGES - Backward compatible!
*/

// ============================================
// TESTING THE CHANGES
// ============================================

/*
1. Start the server:
   npm run dev

2. Test spell correction:
   curl -X POST http://localhost:3000/api/debug/analyze-message \
     -H "Content-Type: application/json" \
     -d '{"message": "ايش درجاتي"}'

3. Check analytics:
   curl http://localhost:3000/api/analytics/chatbot

4. Test in the browser:
   - Navigate to http://localhost:3000
   - Try typo-filled questions
   - Check browser console for debug info
*/
